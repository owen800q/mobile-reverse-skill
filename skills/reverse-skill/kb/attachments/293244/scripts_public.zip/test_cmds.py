#!/usr/bin/env python3
"""Probe which firehose commands this programmer allows."""
import sys
import fh_peek

LOADER = r"D:\迅雷下载\16.0.8.300\xbl_s_devprg_ns.melf"

dev = fh_peek.Dev(sys.argv[1] if len(sys.argv) > 1 else "COM10")
image = open(LOADER, "rb").read()
if not fh_peek.sahara_upload(dev, image):
    sys.exit(1)

tests = [
    ("nop", "<nop />"),
    ("getstorageinfo", '<getstorageinfo physical_partition_number="0"/>'),
    ("peek-addr", '<peek address="0x22126000" length="16"/>'),
    ("peek-addr64", '<peek address64="0x22126000" length="16"/>'),
    ("peek-dec", '<peek address="564838400" length="16"/>'),
    ("getsha256", '<getsha256digest physical_partition_number="0" start_sector="0" num_partition_sectors="1"/>'),
    ("setbootable", '<setbootablestoragedrive value="0"/>'),
    ("getactiveslot", '<getactiveslot />'),
]
for name, cmd in tests:
    ack, txt = fh_peek.fh_cmd(dev, cmd, 8)
    msg = ""
    import re
    m = re.findall(r'message="([^"]*)"', txt)
    if m:
        msg = " | ".join(m)[:100]
    fh_peek.log(f"[*] {name:16s} -> {'ACK' if ack else 'NAK'} {msg}")
