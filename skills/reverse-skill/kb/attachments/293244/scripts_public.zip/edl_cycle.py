#!/usr/bin/env python3
"""Cycle device: firehose <power reset> -> wait adb -> adb reboot edl -> wait 9008.
Usage: python edl_cycle.py [COM10]
If device is already in 9008 (no firehose), still works: reset cmd just fails.
"""
import subprocess
import sys
import time

import serial

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM10"


def log(*a):
    print(*a)
    sys.stdout.flush()


def psql(q):
    r = subprocess.run(["powershell.exe", "-NoProfile", "-Command", q],
                       capture_output=True, text=True, timeout=30)
    return r.stdout


def port_status():
    out = psql("(Get-PnpDevice | Where-Object {$_.FriendlyName -match '9008'}).Status")
    return out.strip()


def try_firehose_reset():
    try:
        s = serial.Serial(PORT, 115200, timeout=2)
        s.reset_input_buffer()
        s.write(b'<?xml version="1.0" ?><data><power value="reset"/></data>')
        time.sleep(1.5)
        s.close()
        log("[*] power reset sent")
    except Exception as e:
        log(f"[*] firehose reset skipped: {e}")


def main():
    try_firehose_reset()
    # wait for adb
    t0 = time.time()
    while time.time() - t0 < 90:
        r = subprocess.run(["adb", "devices"], capture_output=True, text=True)
        if "\tdevice" in r.stdout:
            break
        time.sleep(2)
    else:
        log("[-] adb never came back")
        return 1
    log("[+] adb online")
    subprocess.run(["adb", "reboot", "edl"])
    log("[*] reboot edl sent")
    t0 = time.time()
    while time.time() - t0 < 60:
        if port_status() == "OK":
            log(f"[+] 9008 up after {time.time()-t0:.0f}s")
            time.sleep(1)
            return 0
        time.sleep(2)
    log("[-] 9008 never enumerated")
    return 1


if __name__ == "__main__":
    sys.exit(main())
