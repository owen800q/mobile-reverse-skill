#!/bin/bash
# build & push kmcli (run from repo root in Git Bash)
set -e
export MSYS_NO_PATHCONV=1
"D:\ProgramFiles\LLVM\bin\clang.exe" --target=aarch64-linux-android33 -O2 -fPIE -pie \
  -ffreestanding -fno-stack-protector -nostdlib \
  -o kmcli/kmcli kmcli/kmcli.c vendor_libs/libc.so vendor_libs/libdl.so \
  -Wl,--dynamic-linker,/system/bin/linker64 -Wl,-e,_start
adb push kmcli/kmcli /data/local/tmp/kmcli
adb shell "su -c 'chmod 755 /data/local/tmp/kmcli'"
echo "ok. run: adb shell \"su -c '/data/local/tmp/kmcli 200'\""
