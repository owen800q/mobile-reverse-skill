// kmcli v3 - KeyMint TA raw command client for authorized security research.
//
// Wire format (keymaster.img TA handler @0xe158, VERIFIED little-endian):
//   request : LE32 cmd_id || payload
//   response: LE32 retcode || LE32 payload_len || payload
//
// Transport modes:
//   ku   (default) KeymasterUtils from /vendor/lib64/libkeymasterdeviceutils.so
//        — exactly what the QTI KeyMint HAL uses (MINK invoke op=0 counts=0x11,
//          buffers plain malloc). Verified working protocol on-device.
//   shim = QSEECom_send_cmd of libQSEEComAPI.so (QSEECOMPAT)
//   raw  = direct MINK invoke on shim handle's object (debug)
//
// Build:
//   MSYS_NO_PATHCONV=1 clang --target=aarch64-linux-android33 -O2 -fPIE -pie \
//     -ffreestanding -fno-stack-protector -nostdlib \
//     -o kmcli kmcli.c vendor_libs/libc.so vendor_libs/libdl.so \
//     -Wl,--dynamic-linker,/system/bin/linker64 -Wl,-e,_start

typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef int int32_t;
typedef unsigned long long uint64_t;
typedef uint64_t size_t;
#define NULL ((void *)0)

int printf(const char *fmt, ...);
void *memset(void *s, int c, size_t n);
void *memcpy(void *d, const void *s, size_t n);
unsigned long strtoul(const char *nptr, char **endptr, int base);
extern void *dlopen(const char *filename, int flags);
extern void *dlsym(void *handle, const char *symbol);
extern char *dlerror(void);
extern void *malloc(size_t);
extern int setvbuf(void *stream, char *buf, int mode, size_t size);
extern void *stdout;
extern int open(const char *path, int flags, int mode);
extern long write(int fd, const void *buf, size_t n);
extern long read(int fd, void *buf, size_t n);
extern int close(int fd);
extern char *getenv(const char *name);
extern int sprintf(char *buf, const char *fmt, ...);
#define O_WRONLY_CREAT_TRUNC 0100 | 0001 | 01000
#define _IONBF 2
#define RTLD_NOW 2
#define RTLD_GLOBAL 0x100

typedef int (*start_app_fn)(void **handle, const char *path, const char *appname, uint32_t size);
typedef int (*send_cmd_fn)(void *handle, void *cmd, uint32_t cmd_len, void *rsp, uint32_t rsp_len);
typedef int (*shutdown_app_fn)(void **handle);
typedef int32_t (*mink_invoke_fn)(void *obj, uint32_t op, void *args, uint32_t counts);

// keymasterutils::KeymasterUtils
typedef void (*ku_ctor_fn)(void *self, int32_t security_level);
typedef void (*ku_dtor_fn)(void *self);
typedef int (*ku_send_cmd_fn)(void *self, void *cmd, uint32_t cmd_len, void *rsp, uint32_t rsp_len);
typedef int (*ku_dev_init_fn)(void *self);

extern int __libc_init(void *raw_args, void (*onexit)(void),
                       int (*slingshot)(int, char **, char **), void *structors);
extern void exit(int status);
int main(int argc, char **argv, char **envp);

__attribute__((used))
int slingshot(int argc, char **argv, char **envp) { return main(argc, argv, envp); }
__attribute__((used))
void *g_structors[6] = {0, 0, 0, 0, 0, 0};

__attribute__((naked, used, visibility("default")))
void _start(void) {
    __asm__(
        "mov x0, sp\n"
        "mov x1, xzr\n"
        "adrp x2, slingshot\n"
        "add  x2, x2, :lo12:slingshot\n"
        "adrp x3, g_structors\n"
        "add  x3, x3, :lo12:g_structors\n"
        "bl   __libc_init\n"
        "bl   exit\n"
        "brk  #0\n"
    );
}

static int hexval(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
static size_t hex2bin(const char *hex, uint8_t *out, size_t outcap) {
    size_t n = 0;
    while (hex[0] && hex[1]) {
        if (hex[0] == ' ' || hex[0] == ':') { hex++; continue; }
        int hi = hexval(hex[0]), lo = hexval(hex[1]);
        if (hi < 0 || lo < 0 || n >= outcap) break;
        out[n++] = (uint8_t)((hi << 4) | lo);
        hex += 2;
    }
    return n;
}
static void hexdump(const uint8_t *p, size_t n) {
    for (size_t i = 0; i < n; i += 16) {
        printf("%06zx: ", i);
        for (size_t j = i; j < i + 16 && j < n; j++) printf("%02x", p[j]);
        printf("\n");
    }
}
static int streq(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
static void put_le32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static uint32_t get_le32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void dump_response(const uint8_t *rsp, uint32_t rsp_len) {
    uint32_t rc = get_le32(rsp);
    uint32_t outlen = get_le32(rsp + 4);
    printf("TA retcode = 0x%08x (%d), payload_len = %u\n", rc, (int32_t)rc, outlen);
    if (outlen > rsp_len - 8) { printf("!! outlen exceeds buffer, clamping\n"); outlen = rsp_len - 8; }
    const char *outpath = getenv("KMCLI_OUT");
    if (outpath && outlen) {
        int fd = open(outpath, O_WRONLY_CREAT_TRUNC, 0644);
        if (fd >= 0) { write(fd, rsp + 8, outlen); close(fd); printf("payload -> %s (%u bytes)\n", outpath, outlen); }
    }
    if (outlen > 0x400) {
        printf("payload (first 0x400 bytes):\n");
        hexdump(rsp + 8, 0x400);
    } else {
        printf("payload:\n");
        hexdump(rsp + 8, outlen);
    }
}

int main(int argc, char **argv, char **envp) {
    (void)envp;
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc < 2) {
        printf("usage: kmcli <cmd_id_hex> [payload_hex] [mode=ku|shim|raw]\n");
        printf("       kmcli batch <batchfile>   # lines: <cmd_hex> <payload_hex>\n");
        return 1;
    }
    if (streq(argv[1], "batch")) {
        if (argc < 3) { printf("batch: need file\n"); return 1; }
        int bfd = open(argv[2], 0, 0);
        if (bfd < 0) { printf("batch: open failed\n"); return 2; }
        uint8_t *content = (uint8_t *)malloc(0x100000);
        long n = 0, rn;
        while ((rn = read(bfd, content + n, 0x10000)) > 0) n += rn;
        close(bfd);
        content[n] = 0;
        void *lib = dlopen("/vendor/lib64/libkeymasterdeviceutils.so", RTLD_NOW | RTLD_GLOBAL);
        if (!lib) { printf("dlopen deviceutils failed: %s\n", dlerror()); return 2; }
        ku_ctor_fn ctor = (ku_ctor_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtilsC1E26keymaster_security_level_t");
        ku_dtor_fn dtor = (ku_dtor_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtilsD1Ev");
        ku_send_cmd_fn ksend = (ku_send_cmd_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtils8send_cmdEPvjS1_j");
        if (!ctor || !ksend) { printf("dlsym failed\n"); return 2; }
        void *ku = malloc(0x40);
        memset(ku, 0, 0x40);
        ctor(ku, 1);
        printf("batch: ctor done\n");
        uint8_t *req = (uint8_t *)malloc(0xa000);
        uint8_t *rsp = (uint8_t *)malloc(0xa000);
        char *p = (char *)content, *end = (char *)content + n;
        int idx = 0;
        while (p < end) {
            while (p < end && (*p == ' ' || *p == '\n' || *p == '\r')) p++;
            if (p >= end) break;
            char *tok1 = p;
            while (p < end && *p != ' ' && *p != '\n' && *p != '\r') p++;
            int t1end = *p != ' ' ? 1 : 0;
            char saved = *p; *p = 0;
            uint32_t cmd = (uint32_t)strtoul(tok1, NULL, 16);
            *p = saved;
            const char *phex = "";
            if (!t1end) {
                p++;
                while (p < end && *p == ' ') p++;
                phex = p;
                while (p < end && *p != '\n' && *p != '\r') p++;
                char sv2 = *p; *p = 0;
                memset(req, 0, 0xa000);
                put_le32(req, cmd);
                size_t plen = hex2bin(phex, req + 4, 0x9000);
                *p = sv2;
                memset(rsp, 0, 0xa000);
                int ret = ksend(ku, req, 4 + (uint32_t)plen, rsp, 0xa000);
                uint32_t rc = get_le32(rsp), outlen = get_le32(rsp + 4);
                char oname[128];
                sprintf(oname, "/data/local/tmp/batch_%04d_%x.bin", idx, cmd);
                int ofd = open(oname, 0100 | 0001 | 01000, 0644);
                if (ofd >= 0) { write(ofd, rsp + 8, outlen > 0xa000 - 8 ? 0xa000 - 8 : outlen); close(ofd); }
                printf("[%d] cmd=%x plen=%zu ret=%d rc=%x outlen=%u\n", idx, cmd, plen, ret, rc, outlen);
                idx++;
            } else {
                memset(req, 0, 0xa000);
                put_le32(req, cmd);
                memset(rsp, 0, 0xa000);
                int ret = ksend(ku, req, 4, rsp, 0xa000);
                uint32_t rc = get_le32(rsp), outlen = get_le32(rsp + 4);
                char oname[128];
                sprintf(oname, "/data/local/tmp/batch_%04d_%x.bin", idx, cmd);
                int ofd = open(oname, 0100 | 0001 | 01000, 0644);
                if (ofd >= 0) { write(ofd, rsp + 8, outlen > 0xa000 - 8 ? 0xa000 - 8 : outlen); close(ofd); }
                printf("[%d] cmd=%x ret=%d rc=%x outlen=%u\n", idx, cmd, ret, rc, outlen);
                idx++;
            }
        }
        if (dtor) dtor(ku);
        return 0;
    }
    uint32_t cmd = (uint32_t)strtoul(argv[1], NULL, 16);
    const char *payload_hex = argc > 2 ? argv[2] : "";
    const char *mode = argc > 3 ? argv[3] : "ku";

    // build request in a malloc'd buffer: LE32 cmd || payload
    uint8_t *req = (uint8_t *)malloc(0xa000);
    memset(req, 0, 0xa000);
    put_le32(req, cmd);
    size_t plen = hex2bin(payload_hex, req + 4, 0x9000);
    uint32_t req_len = 4 + (uint32_t)plen;
    printf("cmd=0x%x payload_len=%zu req_len=%u mode=%s\n", cmd, plen, req_len, mode);

    if (streq(mode, "ku") || streq(mode, "kumark") || streq(mode, "seq")) {
        void *lib = dlopen("/vendor/lib64/libkeymasterdeviceutils.so", RTLD_NOW | RTLD_GLOBAL);
        if (!lib) { printf("dlopen deviceutils failed: %s\n", dlerror()); return 2; }
        ku_ctor_fn ctor = (ku_ctor_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtilsC1E26keymaster_security_level_t");
        ku_dtor_fn dtor = (ku_dtor_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtilsD1Ev");
        ku_send_cmd_fn ksend = (ku_send_cmd_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtils8send_cmdEPvjS1_j");
        ku_dev_init_fn dinit = (ku_dev_init_fn)dlsym(lib, "_ZN14keymasterutils14KeymasterUtils16qseecom_dev_initEv");
        printf("ctor=%p dtor=%p send_cmd=%p dev_init=%p\n",
               (void *)ctor, (void *)dtor, (void *)ksend, (void *)dinit);
        if (!ctor || !ksend) { printf("dlsym failed\n"); return 2; }

        // KeymasterUtils object: vtable ptr + ctx ptr (ctor sets everything)
        void *ku = malloc(0x40);
        memset(ku, 0, 0x40);
        ctor(ku, 1);  // 1 = TRUSTED_ENVIRONMENT
        printf("ctor done; ctx=%p\n", *(void **)((uint8_t *)ku + 8));

        uint8_t *rsp = (uint8_t *)malloc(0xa000);
        memset(rsp, 0, 0xa000);
        if (streq(mode, "kumark")) memset(rsp, 0x41, 0xa000);  // marker fill
        if (streq(mode, "seq")) {
            // same session: first send the requested cmd (writes a response),
            // then send 0x21004 to echo the TA-side rsp buffer
            int r1 = ksend(ku, req, req_len, rsp, 0xa000);
            printf("first cmd send -> %d, rc=0x%x len=%u\n", r1, get_le32(rsp), get_le32(rsp + 4));
            memset(req + 4, 0, 0x100);
            put_le32(req, 0x21004);
            memset(rsp, 0x41, 0xa000);
            int r2 = ksend(ku, req, 4, rsp, 0xa000);
            printf("echo cmd send -> %d\n", r2);
            if (r2 == 0) dump_response(rsp, 0xa000);
            if (dtor) dtor(ku);
            return 0;
        }
        int ret = ksend(ku, req, req_len, rsp, 0xa000);
        printf("KeymasterUtils::send_cmd -> %d\n", ret);
        if (ret == 0) dump_response(rsp, 0xa000);
        if (dtor) dtor(ku);
        return ret == 0 ? 0 : 5;
    }

    // ---- shim / raw modes via libQSEEComAPI ----
    void *lib = dlopen("/vendor/lib64/libQSEEComAPI.so", RTLD_NOW);
    if (!lib) { printf("dlopen failed: %s\n", dlerror()); return 2; }
    start_app_fn start_app = (start_app_fn)dlsym(lib, "QSEECom_start_app");
    send_cmd_fn send_cmd = (send_cmd_fn)dlsym(lib, "QSEECom_send_cmd");
    shutdown_app_fn shutdown_app = (shutdown_app_fn)dlsym(lib, "QSEECom_shutdown_app");
    if (!start_app || !send_cmd) { printf("dlsym failed\n"); return 2; }

    const uint32_t SB_SIZE = 0x10000;
    void *h = NULL;
    int ret = start_app(&h, "/vendor/firmware_mnt/image", "keymaster64", SB_SIZE);
    printf("start_app -> %d, handle=%p\n", ret, h);
    if (ret != 0 || !h) return 3;
    uint8_t *sb = *(uint8_t **)h;
    uint32_t sb_len = *(uint32_t *)((uint8_t *)h + 8);
    void *inv_fn = *(void **)((uint8_t *)h + 0x18);
    void *inv_obj = *(void **)((uint8_t *)h + 0x20);
    printf("sb=%p sb_len=0x%x invoke_fn=%p obj=%p\n", sb, sb_len, inv_fn, inv_obj);

    if (streq(mode, "raw")) {
        struct { uint64_t ptr; uint64_t len; } a[2];
        memset(a, 0, sizeof(a));
        uint8_t *rsp2 = (uint8_t *)malloc(0xa000);
        memset(rsp2, 0, 0xa000);
        a[0].ptr = (uint64_t)req; a[0].len = req_len;
        a[1].ptr = (uint64_t)rsp2; a[1].len = 0xa000;
        int32_t r = ((mink_invoke_fn)inv_fn)(inv_obj, 0, a, 0x11);
        printf("raw invoke -> %d\n", r);
        if (r == 0) dump_response(rsp2, 0xa000);
    } else {
        memcpy(sb, req, req_len);
        ret = send_cmd(h, sb, req_len, sb, sb_len);
        printf("send_cmd -> %d\n", ret);
        if (ret == 0) dump_response(sb, sb_len);
    }
    if (shutdown_app) shutdown_app(&h);
    return 0;
}
