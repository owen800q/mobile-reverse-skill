#!/usr/bin/env python3
"""
Upload a given (possibly crafted) melf via Sahara, report whether Firehose
boots, and optionally invoke the implanted <benchmark> handler.

Usage: python probe_melf.py COM10 image.melf [benchmark_addr benchmark_len]
"""
import sys
import time

import fh_peek


def main():
    port, img = sys.argv[1], sys.argv[2]
    bench = None
    if len(sys.argv) > 4:
        bench = (sys.argv[3], int(sys.argv[4], 0))

    image = open(img, "rb").read()
    dev = fh_peek.Dev(port)
    fh_peek.log(f"[*] uploading {img} ({len(image):#x} bytes)")
    t0 = time.time()
    ok = fh_peek.sahara_upload(dev, image)
    fh_peek.log(f"[*] upload result={ok} after {time.time()-t0:.1f}s")
    if not ok:
        fh_peek.log("[-] RESULT: no firehose (hang/reject)")
        return 1
    fh_peek.log("[+] RESULT: firehose booted")

    ack, _ = fh_peek.fh_cmd(dev, "<nop />", 10)
    fh_peek.log(f"[*] nop -> {'ACK' if ack else 'NAK/timeout'}")

    if bench:
        addr, length = bench
        cmd = f'<benchmark address="{addr}" length="{length}"/>'
        fh_peek.log(f"[*] invoke {cmd}")
        dev.wr((f'<?xml version="1.0" ?><data>{cmd}</data>').encode())
        payload = b""
        raw_expect = None
        t0 = time.time()
        while time.time() - t0 < 45:
            if raw_expect is not None:
                payload += dev.rd(raw_expect - len(payload), 15)
                if len(payload) >= raw_expect:
                    break
                continue
            kind, txt = fh_peek.fh_read_packet(dev, 10)
            if kind != "xml":
                continue
            fh_peek.fh_show_logs(txt)
            if 'rawmode="true"' in txt:
                raw_expect = length
                fh_peek.log("[*] rawmode announced")
                continue
            if "<response" in txt:
                fh_peek.log(f"[*] response: {txt.strip()[:160]}")
                if raw_expect is None:
                    break
        if payload:
            fh_peek.log(f"[+] IMPLANT WORKS: {len(payload):#x} raw bytes")
            fh_peek.log(f"    first64: {payload[:64].hex()}")
            open("hook_probe.bin", "wb").write(payload)
            return 0
        fh_peek.log("[-] implant not active")
    return 0


if __name__ == "__main__":
    sys.exit(main())
