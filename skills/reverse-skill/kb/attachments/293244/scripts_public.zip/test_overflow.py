#!/usr/bin/env python3
"""Sahara oversized-response probe: answer READ_DATA with MORE than requested.
Usage: test_overflow.py COM10 <pad_bytes|single>
  pad_bytes: serve requested range + N extra bytes
  'single':  serve entire image in one write regardless of request
"""
import struct
import sys
import time

import serial

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM10"
MODE = sys.argv[2] if len(sys.argv) > 2 else "0x1000"
LOADER = r"D:\迅雷下载\16.0.8.300\xbl_s_devprg_ns.melf"

image = open(LOADER, "rb").read()
s = serial.Serial(PORT, 115200, timeout=3)
s.reset_input_buffer()
s.write(struct.pack("<II", 0x7, 0x8))
time.sleep(0.4)
hello = s.read(0x30)
if len(hello) < 0x30 or struct.unpack_from("<I", hello)[0] != 1:
    print(f"[-] no HELLO ({len(hello)}B)")
    sys.exit(1)
print("[+] HELLO_REQ")
s.write(struct.pack("<12I", 2, 0x30, 2, 1, 0, 0, 1, 2, 3, 4, 5, 6))

t0 = time.time()
reqs = 0
while time.time() - t0 < 30:
    hdr = s.read(8)
    if len(hdr) < 8:
        continue
    if hdr.startswith(b"<?xml"):
        print("[+] FIREHOSE XML - booted normally (no effect)")
        break
    cmd, ln = struct.unpack("<II", hdr)
    if cmd == 0x03:
        body = s.read(12)
        iid, off, dlen = struct.unpack("<III", body)
    elif cmd == 0x12:
        body = s.read(24)
        iid, off, dlen = struct.unpack("<QQQ", body)
    elif cmd == 0x04:
        body = s.read(8)
        iid, status = struct.unpack("<II", body)
        print(f"[+] END_TRANSFER status={hex(status)} - survived")
        break
    else:
        print(f"[-] cmd {hex(cmd)} len {ln}")
        break
    reqs += 1
    if MODE == "single":
        if reqs == 1:
            print(f"[*] single-shot: asked {dlen:#x}, sending {len(image):#x}")
            s.write(image)
            s.flush()
            time.sleep(1)
            # observe
            r = s.read(64)
            print(f"[*] post-blast: {len(r)}B {r[:32].hex()}")
            continue
        s.write(image[off:off + dlen])
    else:
        pad = int(MODE, 0)
        if reqs == 1:
            print(f"[*] request off={off:#x} len={dlen:#x} -> serving +{pad:#x} extra")
            s.write(image[off:off + dlen] + b"A" * pad)
        else:
            s.write(image[off:off + dlen])
print(f"[*] done, reqs={reqs}")
s.close()
