#!/usr/bin/env python3
"""
Minimal Sahara + Firehose client (Sahara v3 / SM8750 proven handshake).

edl V3.62 hangs on this device's v3 PBL (its connect() probing desyncs the
state machine). This client does exactly and only:
  Sahara upload of a signed programmer (multi-stage MELF aware)
  -> Firehose XML <peek>.

Multi-stage note (measured on this device): PBL pulls only the 0x904-byte
RV32 stub first (ELF hdr + phdrs + 2 segments), END_TRANSFER status=0, then
the STUB re-handshakes and pulls the main body. We keep serving READ_DATA
requests (offsets are into the whole MELF file) until Firehose XML shows up.

Usage:
  python fh_peek.py COM10 loader.melf 0x81D00000 0x100 out.bin
"""

import re
import struct
import sys
import time

import serial


def log(*a):
    print(*a)
    sys.stdout.flush()


XML_START = b"<?xml"
XML_END = b"</data>"


class Dev:
    def __init__(self, port):
        self.s = serial.Serial(port, 115200, timeout=2)
        self.s.reset_input_buffer()
        self.s.reset_output_buffer()
        self.pushback = b""

    def rd(self, n, t=3.0):
        self.s.timeout = min(t, 15)
        buf = b""
        t0 = time.time()
        while len(buf) < n and time.time() - t0 < t:
            buf += self.s.read(n - len(buf))
        return buf

    def wr(self, b):
        self.s.write(b)


HELLO_RSP_IMG = struct.pack("<12I", 2, 0x30, 2, 1, 0, 0, 1, 2, 3, 4, 5, 6)


def sahara_upload(dev, image):
    """Serve the MELF until Firehose XML appears. True on success."""
    dev.wr(struct.pack("<II", 0x7, 0x8))       # RESET_REQ
    time.sleep(0.4)
    hello = dev.rd(0x30, 6)
    if len(hello) < 0x30 or struct.unpack_from("<I", hello)[0] != 1:
        log(f"[-] no HELLO_REQ ({len(hello)}B)")
        return False
    f = struct.unpack("<12I", hello)
    log(f"[+] HELLO_REQ v{f[2]} pkt={hex(f[4])}")
    # IMAGE_TX_PENDING (mode 0); v3 quirk: answer version=2, max_cmd_len=0
    dev.wr(HELLO_RSP_IMG)

    served = 0
    t_start = time.time()
    while time.time() - t_start < 120:
        hdr = dev.rd(8, 20)
        if len(hdr) < 8:
            log("[-] timeout waiting for request")
            return False
        if hdr.startswith(XML_START):
            # firehose is up: finish this packet and hand it to the XML layer
            pkt = hdr
            t0 = time.time()
            while XML_END not in pkt and time.time() - t0 < 5:
                pkt += dev.rd(256, 1)
            dev.pushback = pkt
            log("[+] firehose XML detected - boot complete")
            return True

        cmd, ln = struct.unpack("<II", hdr)
        if cmd == 0x01 and ln == 0x30:                    # next-stage HELLO_REQ
            dev.rd(0x30 - 8, 3)
            dev.wr(HELLO_RSP_IMG)
            log("[+] next-stage HELLO -> answered")
            continue
        if cmd == 0x03:                                   # READ_DATA 32-bit
            body = dev.rd(12, 3)
            iid, off, dlen = struct.unpack("<III", body)
        elif cmd == 0x12:                                 # READ_DATA 64-bit
            body = dev.rd(24, 3)
            iid, off, dlen = struct.unpack("<QQQ", body)
        elif cmd == 0x04:                                 # END_TRANSFER
            body = dev.rd(8, 3)
            iid, status = struct.unpack("<II", body)
            log(f"[+] END_TRANSFER image_id={hex(iid)} status={hex(status)} "
                f"(served {served:#x})")
            if status != 0:
                return False
            dev.wr(struct.pack("<II", 0x5, 0x8))          # DONE_REQ
            rsp = dev.rd(12, 10)
            if len(rsp) >= 8 and struct.unpack_from("<I", rsp)[0] == 0x06:
                log("[+] DONE_RSP - stage booting")
                continue
            log(f"[-] DONE failed: {rsp.hex()}")
            return False
        else:
            log(f"[-] unexpected cmd {hex(cmd)} len {ln}")
            return False

        if off + dlen > len(image):
            log(f"[-] request beyond image: off={hex(off)} len={hex(dlen)}")
            return False
        dev.wr(image[off:off + dlen])
        served += dlen
        if served and served % (256 * 1024) < 0x400:
            log(f"    ... served {served:#x} bytes")
    log("[-] upload loop timeout")
    return False


def fh_read_packet(dev, t=10.0):
    """Read one firehose XML frame; returns ('xml', text) or ('timeout', buf)."""
    buf = dev.pushback
    dev.pushback = b""
    t0 = time.time()
    while not buf.endswith(XML_START) and XML_START not in buf:
        if time.time() - t0 > t:
            return ("timeout", buf)
        b = dev.rd(1, 1)
        if not b:
            continue
        buf += b
        if buf.endswith(XML_START):
            buf = XML_START
        elif len(buf) > 64:
            buf = buf[-64:]
    if XML_START in buf and not buf.startswith(XML_START):
        buf = buf[buf.index(XML_START):]
    while XML_END not in buf and time.time() - t0 < t:
        b = dev.rd(1, 1)
        if not b:
            continue
        buf += b
    if XML_END not in buf:
        return ("timeout", buf)
    end = buf.index(XML_END) + len(XML_END)
    if buf[end:]:
        dev.pushback = buf[end:]
    return ("xml", buf[:end].decode("utf-8", "replace"))


def fh_show_logs(txt):
    for m in re.finditer(r'message="([^"]*)"', txt):
        log(f"    [fh] {m.group(1)[:110]}")


def fh_cmd(dev, xml_body, t=30):
    """Send a firehose command, return (ack: bool, full_xml: str)."""
    dev.wr((f'<?xml version="1.0" ?><data>{xml_body}</data>').encode())
    alltxt = ""
    t0 = time.time()
    while time.time() - t0 < t:
        kind, txt = fh_read_packet(dev, 10)
        if kind != "xml":
            continue
        alltxt += txt
        fh_show_logs(txt)
        if "<response" in txt:
            return 'value="ACK"' in txt, alltxt
    return False, alltxt


def fh_peek(dev, addr_str, length):
    # handshake: some firehose want a nop first
    ok, _ = fh_cmd(dev, "<nop />", 10)
    log(f"[*] nop -> {'ACK' if ok else 'no ack (continuing)'}")
    cmd = f'<peek address="{addr_str}" length="{length}"/>'
    dev.wr((f'<?xml version="1.0" ?><data>{cmd}</data>').encode())
    payload = b""
    raw_expect = None
    t0 = time.time()
    while time.time() - t0 < 60:
        if raw_expect is not None:
            payload += dev.rd(raw_expect - len(payload), 15)
            if len(payload) >= raw_expect:
                raw_expect = None
            continue
        kind, txt = fh_read_packet(dev, 10)
        if kind != "xml":
            continue
        fh_show_logs(txt)
        if 'rawmode="true"' in txt:
            raw_expect = length
            continue
        if "<response" in txt:
            if 'value="ACK"' in txt:
                return payload
            log(f"[-] firehose NAK: {txt.strip()[:300]}")
            return None
    log("[-] peek timeout")
    return None


def main():
    port, loader, addr_s, len_s, out = sys.argv[1:6]
    addr_s_out, length = addr_s, int(len_s, 0)
    image = open(loader, "rb").read()
    log(f"[*] loader {len(image):#x} bytes, peek {addr_s} len {len_s}")

    dev = Dev(port)
    if not sahara_upload(dev, image):
        return 1

    data = fh_peek(dev, addr_s_out, length)
    if data is None:
        return 1
    log(f"[+] peek ok: {len(data)} bytes")
    open(out, "wb").write(data)
    log(f"[+] saved -> {out}")
    log(f"    first64: {data[:64].hex()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
