#!/usr/bin/env python3
"""Sahara MEMORY_DEBUG mode probe: hello(mode=2) then 64-bit MEMORY_READ."""
import struct
import sys
import time

import serial

PORT = sys.argv[1] if len(sys.argv) > 1 else "COM10"
ADDR = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x22126000
LEN = int(sys.argv[3], 0) if len(sys.argv) > 3 else 0x100

s = serial.Serial(PORT, 115200, timeout=3)
s.reset_input_buffer()
s.write(struct.pack("<II", 0x7, 0x8))  # RESET_REQ
time.sleep(0.4)
hello = s.read(0x30)
if len(hello) < 0x30 or struct.unpack_from("<I", hello)[0] != 1:
    print(f"[-] no HELLO_REQ ({len(hello)}B) {hello[:16].hex()}")
    sys.exit(1)
f = struct.unpack("<12I", hello)
print(f"[+] HELLO_REQ v{f[2]}")

# HELLO_RSP: mode=2 (MEMORY_DEBUG)
s.write(struct.pack("<12I", 2, 0x30, 2, 1, 0, 2, 1, 2, 3, 4, 5, 6))
time.sleep(0.5)
resp = s.read(0x40)
print(f"[*] after debug-hello: {len(resp)}B {resp.hex()}")
if resp:
    cmd = struct.unpack_from("<I", resp)[0]
    print(f"    first cmd = {cmd:#x} (0x9/0x10=MEMORY_DEBUG table)")
    if cmd in (0x9, 0x10):
        if cmd == 0x10 and len(resp) >= 0x18:
            _, _, addr, ln = struct.unpack_from("<IIQQ", resp)
            print(f"    memory table @ {addr:#x} len {ln:#x}")
        # now issue 64-bit MEMORY_READ
        s.write(struct.pack("<IIQQ", 0x11, 0x18, ADDR, LEN))
        time.sleep(0.5)
        data = s.read(LEN + 0x20)
        print(f"[*] MEMORY_READ got {len(data)}B: {data[:64].hex()}")
        if data:
            open("sahara_memread.bin", "wb").write(data)
else:
    print("[-] no response to debug-mode hello (likely unsupported/locked)")
s.close()
