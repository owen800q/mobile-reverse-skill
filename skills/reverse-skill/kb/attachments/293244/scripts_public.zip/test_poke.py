#!/usr/bin/env python3
"""Upload clean loader, test <poke> support on scratch DDR."""
import sys
import fh_peek

LOADER = r"D:\迅雷下载\16.0.8.300\xbl_s_devprg_ns.melf"

dev = fh_peek.Dev(sys.argv[1] if len(sys.argv) > 1 else "COM10")
image = open(LOADER, "rb").read()
if not fh_peek.sahara_upload(dev, image):
    sys.exit(1)
ok, _ = fh_peek.fh_cmd(dev, "<nop />", 10)
fh_peek.log(f"[*] nop -> {'ACK' if ok else 'NAK'}")

# poke 4 bytes to scratch DDR 0xd8000000
cmd = '<poke address64="3489660928" size_in_bytes="4" value64="0x44332211"/>'
ack, txt = fh_peek.fh_cmd(dev, cmd, 15)
fh_peek.log(f"[*] poke -> {'ACK (WRITE WORKS!)' if ack else 'NAK'}")
if not ack:
    # try alternate attribute spellings
    cmd = '<poke address64="0xd8000000" SizeInBytes="4" value64="0x44332211"/>'
    ack, txt = fh_peek.fh_cmd(dev, cmd, 15)
    fh_peek.log(f"[*] poke alt -> {'ACK (WRITE WORKS!)' if ack else 'NAK'}")
    fh_peek.log(txt[:400])
