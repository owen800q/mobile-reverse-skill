# CVE-2026-25262 / CDI_Leaf 提取 — 会话进展 (2026-10-09)

## 目标
提取 SM8750P 设备 (TB322FC, OPD2413_16.0.8.300) 的 KeyMint CDI_Leaf 种子，
供 google-rkp-sw/rkp_sw.py 离线 provisioning。

## KeyMint TA 分析结论 (keymint_cdi_analysis.md)
- CDI_Leaf = 32B Ed25519 种子 = KDF(SHK, "RKP PRIVATE KEY SEED"/"Device Key Seed")
- 运行时位于 keymaster TA 全局: base+0x67761 (种子), base+0x67741 (公钥), flag 0x67740
- 种子紧跟公钥: seed = pub_addr + 0x20
- 触发: GENERATE_CSR_V2 无条件派生/加载 (SFS 缓存 DK_PRIV/DK_PUB)
- 设备真实叶子公钥 (已从 rkp_csr_default.txt 验证提取, 存 cdi_leaf_pub.bin):
  <DEVICE_PUBKEY_REDACTED>
  (验证了它正是 SignedData COSE_Sign1 的签名者)
- DDR 扫描计划: 找公钥模式 -> +0x20 即种子, Ed25519 派生校验

## 设备触发 CSR (种子驻留 TA 内存)
adb shell cmd remote_provisioning csr default
(certify 子命令需要 GMS 网络授权, 不可用, 也不需要)

## MELF 各阶段验证实验 (实测, COM10 Sahara v3)
melf = 5 个拼接 ELF:
- elf0 @0x0:    RV32 stub -> 0x22126000 (TME SRAM)
- elf1 @0x904:  RV32 TME fw -> 0x20415100 (12 phdrs, 签名段 ph11 @0xa98)
- elf2 @0x2e574: A64 entry 0x14825fa8 -> 0x14800000+
- elf3 @0x122154: A64 entry 0x149997a8 -> 0x14999000+ (含 benchmark handler 0x149a46f0)
- elf4 @0x16e428: A64 entry 0x1494e000 -> 0x1494e000+

关键地址: benchmark handler va 0x149a46f0 = fh_elf3.bin +0xb6f0 = melf 文件 0x12e844
(锚定: fh_elf3[0x1000] == melf[0x124154])
helper: ATTR_GET 0x149ac724 / GET_CTX 0x149cbe0c / RESPOND 0x149a28bc /
        TX 0x149abbf8 / FREE_CTX 0x149cbe98
v5 成品 A64 peek payload: exploit_hook_v5.melf 文件 0x414 起 0x17c 字节 (已验证反汇编)

实测结果:
| 修改对象 | 结果 |
|---|---|
| elf0 seg0 数据 (hook_v5/hang) | status=0, firehose 正常启动 — 数据不校验 |
| elf0 stub hang 补丁 (jal x0,0 @file 0xa0) | firehose 照样启动 — **stub 从不执行** |
| elf0 phdr 改动 (hijack_ret) | status=0x30 @served 0x684 — header/phdr 有哈希, 拉数据前先验 |
| elf2 数据 1 字节 | status=0x22 @0x11f8cc (elf2 尾部) — 校验 |
| elf3 数据 (benchmark handler 直patch) | status=0x22 @0x16ad68 — 校验 |
| elf1 数据 1 字节 (字符串) | status=0x22 @0x2cab4 (elf1 尾部) — 校验, 但**拉完才验** (copy-before-verify!) |
| elf1 ph7 p_paddr 改动 | 待测 (canary_elf1_phdr.melf 已修好, 设备挂了没跑成) |

结论: 只有 elf0 数据段不校验且不执行; elf1+ 都是"先拷贝后验签"(CVE 模式),
若 elf1 的 phdr 不在哈希覆盖内 -> write-what-where 成立 (已知内容写任意地址),
配合 elf0 数据段的自定义代码 (在 0x22126000) 可构造 TME 代码执行链。

## 工具
- edl_cycle.py: firehose power reset -> adb -> reboot edl -> 等 COM10
- probe_melf.py COM10 img.melf [bench_addr bench_len]: 上传+可选 benchmark 探针
- test_hook.py: v5 stub hook 专用测试
- canary_*.melf: 各阶段校验探针

## 第二轮实测 (完整验签地图)
| 测试 | 结果 |
|---|---|
| elf1 ph7 phdr 重定向 | NAK 0x21 @0x3730 (header/phdr 先验) |
| elf2 phdr | NAK 0x25 @0x2ccec |
| elf3 phdr | NAK 0x25 @0x11fa94 |
| elf4 phdr | NAK 0x21 @0x16c344 |
| elf4 数据 | NAK 0x22 (全量拉完后拒) |
| Sahara MEMORY_DEBUG hello (mode=2) | NAK 0x1b |
| Sahara 超量应答 (+0x1000) | NAK 0x8 后状态机死亡 |
| firehose: nop/getstorageinfo/configure/read | ACK (flash 读可用!) |
| firehose: peek/poke/getsha256digest/getactiveslot | NAK |
| "Peek is disabled on secure boot devices" @ fh_elf3.bin+0x3c282 | peek 硬门控 |
| elf0 数据区 (0x22126000) 在 elf2/3/4 中的引用 | 无 — 死数据 |

**总结论: 此 PBL (Sahara v3, OPD2413_16.0.8.300) 对所有执行阶段做
header+phdr 前置哈希 + 数据段尾校验。CVE-2026-25262 的 write-what-where
在此固件不成立。9008 只剩: flash 分区读写 (read 已验证, program 未测)。**

elf4 = CFGL (DDR 训练配置 pre-ddr-pakala dtb/dcb/cpr), 纯数据非代码。
fh_elf4.bin[0] = "CFGL"。

## 转向路线 A: KeyMint TA 攻击面 (无需 9008)
TA 从 NS 世界收命令 (keystore2 / cmd remote_provisioning csr default)。
审计 CSR/DeviceInfo/x509/attestation 参数解析找 OOB 读/信息泄露,
目标是把 base+0x67761 的 32B 种子漏进响应。分析见 keymint_cdi_analysis.md
"Attack Surface" 章节 (agent-0 持续更新)。

## 其他线索
- xbl_sc_logs_live.bin / lenovolock.bin = 分区回读 (高熵/加密, 无泄露)
- GeekFlashTool.exe = Qt 程序, _ConnectServer -> 在线授权, Qcom 侧只有
  Diag/nvitems.xml, 9008 授权形态待 WREN 确认
- apdp/apdpb 分区存在 (authenticated debug policy) — 若授权工具能写 apdp
  可开 JTAG 调试, 另是一条路

## 第三轮: 设备有 KernelSU root! (2026-10-09 下午)
- `su -c id` = uid=0 ksu; SELinux Enforcing; kernel 6.6.89-android15
- 模块: Shamiko/tricky_store/TA_enhanced/zygisksu; /data/local/tmp 有她的
  .cv 加载器系列 + .dc.ko (displaycal 内核模块, vermagic 6.6.118 vs 当前 6.6.89)
- /dev/qseecom 无; 有 /dev/smcinvoke + libQSEEComAPI.so
- /vendor/bin: KmInstallKeybox / StoreKeybox(Widevine) / check_keymaster
- 内存地图: tz_merged @0xd8000000 (6MB QTEE), gunyah_hyp @0x80000000,
  xbl_ramdump @0xb8000000, ramoops @0xc2000000 (空)
- strongbox RKP 组件: csr strongbox 叶子公钥
  <DEVICE_PUBKEY2_REDACTED>
  (QUALCOMM / "RKP Device Key", 2 级退化链) -> SPU 侧第二个种子目标
- nonce 复用: 10 CSR 0 复用, Ed25519 规范实现, 排除

## KeyMint TA 攻击面审计结论 (agent-0)
- 无直接 OOB 读; CSR challenge<=64B 硬校验, memcpy min 钳制
- 候选1: 0x219 FRS_AND_UDS — 设计回传 FRS 给 NS, 量产预期 -0x2711 门
- 候选2: 0x3126 RKP_HMAC — NS 可达 HMAC-SHA256 oracle (SHK 派生 key)
- 候选3(最现实): 堆残留泄露 — 首 CSR 后 32B 种子进堆 -> free 不擦 (0x3fb58),
  malloc 不清零; 缺"分配到同块+回传"原语, 嫌疑 x509 两遍长度族
  (0x225c0/0x2266c) + 0x35cb8 反序列化; 建议定向 fuzz
- 96 命令表已还原 (disasm_tmp/cmdname.py); TA 入口 handleRequest @0x102b0

## 并行任务
- agent-0: kmcli (root 直连 TA), 实测 0x219/0x3126
- agent-1: spuservice.img 强盒种子定位
- agent-2: abl.img fastboot oem 攻击面审计
- vendor_libs/: libQSEEComAPI/libqtikeymint/libspukeymint*/HAL/bionic 已拉取

## ABL fastboot 攻击面 (2026-10-09, agent)
abl.img = ELF32 容器 + UEFI FV + LZMA(GUID EE4E5898-…) + PE32+/AArch64 (LinuxLoader)。
解压产物 disasm_tmp/db_abl/abl_image.bin，分析脚本 disasm_tmp/abl_build_db.py / abl_dis.py。
结论：33 条 fastboot 命令（表 @PE 0x873e0）；无 peek/poke/dump 内存原语；
unlock 只有 Lenovo RSA-2048 token (getRandom→token→unlock-flash) 或 lenovolock
合法结构 ("1a2blenovo3c4d5e"+SHA256+安全存储交叉校验)，无离线伪造路径；
`oem edl` 锁态可进 9008（唯一实用原语入口）。详见 abl_fastboot_analysis.md。

## CVE-2026-25302 评估 (2026-10-09, agent)
xbl_a = 三段拼接 ELF: RV32 TME stub @0 / RV32 TME fw @0x904 / A64 XBL 主体 @0x2e574
(entry 0x14825fa8, 代码 0x14825000+0x90000)。工具 disasm_tmp/{xbl_parse,xbl_build_db,
xbl_sfind,xbl_dis}.py + db_xbl/。
关键结论:
- imagefv_a 解压后是 BMP 资源库(13 张 logo/battery bmp), **不是摘要表**; 且本身已签名。
- tz/hyp/abl/keymaster/devcfg/xbl_config/featenabler 全部 ELF+v7 hash 段+证书链。
- 非 ELF 分区只有 ddr(数据)/cdt(全零)/tzsc(全零) —— 设计不验签但无可执行内容。
- XBL 装载表 @0x148ce9c8 (19 项, 步长 0x88): 无 keymaster/imagefv 条目;
  keymaster TA 由 QTEE 运行时验签, 与 XBL 无关。
- 判定: CVE-2026-25302 在本设备**不能单独**让未签名 keymaster/tz 启动;
  只剩 ddr/cdt 解析器(0x148268f4 等) 0day 路线。详见 xbl_imagefv_analysis.md。

## 最终突破 (2026-10-09): Oracle 路线出 keybox, 无需种子
- kmcli 直连 KeyMint TA 成功 (ku 模式, libkeymasterdeviceutils MINK IPC)
- 0x3122 CSR_V2 非 FIXED 路径不验 MAC, bare COSE_Key 数组直接接受
- 请求格式: CBOR map {4: challenge(<=64B), 57: bstr(cbor [COSE_Key])}
- 响应 = {61: bstr(AuthenticatedRequest)}, 需解包
- 全流程: rkp_oracle.py <outdir> = fetchEekChain -> kmcli 3122 -> signCertificates -> keybox.xml
- 已出两个 keybox (工作区根目录 + Desktop\test), 链签名验证到 Google 根全 VALID
- Google 服务器配置: num_extra_attestation_keys=12, challenge 29B, 72h 刷新
