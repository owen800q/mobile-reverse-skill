# SPUService TA (spuservice.img) — strongbox RKP CDI_Leaf 定位分析

- 目标固件: `firmware/spuservice.img`（SM8750P / Snapdragon 8 Elite，128KB，ELF64 AArch64 ET_DYN，entry=0）
- 工具: capstone 线性反汇编 + dynsym/字符串 xref（脚本 `disasm_tmp/spu_*.py`，数据库 `disasm_tmp/db_spu/`；复用 keymaster.img 分析模式）
- 所有地址为 ELF 虚拟地址（vaddr）。**文件偏移 = vaddr + 0x1000**（对所有 LOAD 段成立）。
- **核心结论：strongbox RKP/CDI_Leaf 不在这个镜像里。** 本 TA 没有任何密码学能力（证据见 §2/§3），它是 KeyMint TA ↔ SPU 之间的**配置（provisioning）中继服务**。strongbox CSR 的 CDI_Leaf 等价物由 SPU 侧固件持有（§6）。

## 1. ELF 结构

ELF64 / AArch64 / ET_DYN / **有 dynsym + dynstr**（与 keymaster.img 不同），无 section header（`e_shoff=0`）。LOAD 段之后拼有哈希段（phdr[8] NULL, off 0x15000, size 0x1058），其余为 0 填充至 0x20000。

| phdr | 类型 | 文件偏移 | vaddr | filesz | 权限 |
|---|---|---|---|---|---|
| 1 | LOAD | 0x1000 | 0x0 | 0xdf98 | R-X（代码+rodata，仅 ~57KB，keymaster 的 1/7） |
| 2 | LOAD | 0xf000 | 0xe000 | 0xe5 | RW（TA 元数据：`TA_APP_NAME`="spu_service" @0xe000，`TA_METADATA` @0xe080） |
| 3 | LOAD | 0x10000 | 0xf000 | 0x1d0 | RW（GNU_RELRO，GOT——文件中为 0，loader 重定位填充） |
| 4 | LOAD | 0x11000 | 0x10000 | 0x421 | RW（全局变量区） |
| 6 | LOAD | 0x12000 | 0x11000 | 0x2dfc | RW（DYNAMIC @0x11000 + HASH/SYMTAB/STRTAB + 全局） |

前 ~0x200 字节是 veneer 表（`adrp x16,#0xf000; ldr x17,[x16,#off]; br x17`），JMPREL（va 0x11490，23 项）给出每个 GOT 槽的符号名，即本 TA 的**全部外部服务**。

## 2. dynsym —— 决定性证据

DYNAMIC：SYMTAB va 0x11d58（193 个符号）、STRTAB va 0x12f70、HASH va 0x11748、RELA va 0x11130（24 项）、JMPREL va 0x11490（23 项）。

**导入（undefined）符号全集**（veneer → QSEE 服务）：

| veneer | 符号 | veneer | 符号 |
|---|---|---|---|
| 0x20 | qsee_log | 0xd0 | qsee_sfs_error |
| 0x30 | qsee_log_set_mask | 0xe0 | qsee_sfs_write |
| 0x40 | qsee_malloc | 0xf0 | qsee_cfg_getpropval |
| 0x50 | qsee_free | 0x100 | qsee_spcom_register_client |
| 0x60 | qsee_open | 0x110 | qsee_spcom_client_is_server_connected |
| 0x70 | qsee_sfs_rm | 0x120 | qsee_get_uptime |
| 0x80 | qsee_open_singleton | 0x130 | qsee_spcom_client_send_message_sync |
| 0x90 | qsee_sfs_open | 0x140 | qsee_spcom_unregister_client |
| 0xa0 | qsee_sfs_getSize | 0x150 | qsee_err_fatal |
| 0xb0 | qsee_sfs_close | 0x170-0x1d0 | cmnlib_init / GPAppLib_init / appInit / appShutdown / release / handleRequest / CApp_openSession |
| 0xc0 | qsee_sfs_read | 0x1e0 | TEE_Wait |

**没有任何加密服务**：无 HW crypto SHK KDF（对比 keymaster.img veneer 0x230）、无 RNG、无 Ed25519/HMAC/AES 导入。导出符号 likewise 只有 QCBOR 编解码、buffer 工具、spcom 中继与 provisioning 逻辑（`send_spu_auth_token_key`、`send_spu_pre_shared_key`、`spu_create_km_provision_device_id_cmd`、`attestation_key_provision`、`getIdentityCredAttestation`、`get_eccPrivate_key_asn1_der`、`validateCerts`、`x509_verify` 等）。

## 3. 字符串扫描

359 个字符串中，RKP / CSR / CDI / UDS / seed / BCC / DICE / ed25519 / hmac / derive / keymint(命令) 全部 **0 命中**（`spu_build_db.py` 输出）。
存在的密钥相关字符串仅为 provisioning 存储文件名与日志：

```
0x00ad9f 'sp_keymint_device_id'        ; SFS 文件名（设备 ID）
0x00adb4 'sp_keymint_attest_key'       ; SFS 文件名（attestation key 数据）
0x00b0c6 'sp_keymint_prov_lock_status' ; SFS provisioning 锁
0x00bdb9 'sp_keymaster'                ; CKMHal 对端 = keymaster TA
0x00b4a9 'allow_reprovision_device_ids' / 0xb4c6 'allow_reprovision_keybox'
0x00b4df 'block_reprovision_device_ids_non_secure'
0x00d119 'getIdentityCredAttestation' / 0xd206 'get_eccPrivate_key_asn1_der'
```

本地代码也无软件加密实现：SHA-256（`67 e6 09 6a`、`98 2f 8a 42`）、SHA-1、AES T-table、ChaCha "expand 32-byte k"、Ed25519 常数、HMAC ipad 模式在 RX 段全部 absent。

**结论（任务 3/5）：本镜像不存在也不可能派生/存放 Ed25519 种子——没有 KDF、没有 RNG、没有任何密码学原语，也没有 'RKP PRIVATE KEY SEED' 类 label。** CDI_Leaf 派生路径（KDF(SHK, label)→全局 buffer）在此镜像中不存在对应物。

## 4. 命令分发表（NS 攻击面入口）

TA 入口：`CSPService_open`（0x3c4，uid==0x128 校验）注册 CApp 对象，vtable 0x4d8 = invoke 分发器。
分发器（0x4d8）：`cmd = w1 & 0xffff`，要求 `cmd ≤ 0x12`，跳表 @va 0xac42（19 个 halfword 偏移，base 0x540）：

| cmd | case | 语义 |
|---|---|---|
| 0x0/0xb | 0x540 | `spu_create_km_provision_device_id_cmd`（0x3228）：8 个 NS 字符串 → CBOR provisioning 命令 |
| 0x1 | 0x678 | 读回已注册的 SPU 共享 buffer (ptr,len)（全局 0x100b0） |
| 0x2 | 0x6a0 | `CSPServicePrivate_read`（0xea0）：按 key_tag 读 SFS/RPMB → 回传 NS |
| 0x3 | 0x6dc | 同读路径（双 buffer 变体，0x1aa4 拆分参数） |
| 0x4 | 0x74c | 0x1148 |
| 0x5 | 0x7a8 | 0x12e8 |
| 0x6/0xc | 0x804/0x964 | 0x14e8：打开 CSPCOM 单例（UID 0x37），注册 NS buffer 为 SPU 共享 buffer（g 0x10078，"Shared buffer initialized successfully"） |
| 0x7 | 0x830 | 校验 "TSID" magic → `km_provisioning_by_key`（0x2058）：发 SPU + 写 SFS/RPMB |
| 0x8 | 0x87c | 校验 "STTA" magic → 0x2058（attest key 版） |
| 0x9/0xa | 0x8f4/0x90c | **SPU 命令透传**：NS payload（前 4 字节须=0x51a/0x51b）经 `spu_km_verify_cmd_hdr`（0x31c0）→ `send_spu_cmd`（0x251c→0x3090），响应拷回 NS |
| 0xd | 0x9b0 | `send_spu_auth_token_key`（0x2830）：从 keymaster TA 取 auth token key（`IKMHal_getAuthTokenKey256`）发 SPU，再 0x265c 发 set_provisioned_data（tag 0x270a/0x270b） |
| 0xe | 0x9dc | `CSPServicePrivate_write`（0x167c）：NS 写 key_tag 数据到 SFS/RPMB |
| 0xf | 0xa40 | attestation key provisioning 编排：malloc 0x400，打开 CKMHal（UID 0x96，'sp_keymaster'），`IKMHal_getDeviceInfo`，`send_spu_set_provisioned_data_cmd`（0x2e44），`spu_create_get_device_info_cmd`（0x38ec），按 NS 给的 u64==3 条件再走 0x251c |
| 0x10 | 0xab0 | 0x251c 透传（带 4B 输出值） |
| 0x11 | 0xaf8 | 0x1aa4 拆参 + 长度复核 + 0x167c 写 |
| 0x12 | 0xb64 | 设置 SPU 共享 buffer 指针（g 0x100b0/0x100b8） |

所有 case 均先校验参数类型字 `w3` 和每个 buffer 的长度（如 `cmp x8,#4; b.ne err`）。

## 5. OOB / 信息泄露审计结果

- **拷办函数 0x3ffc 是钳制拷贝**：`n = min(dst_len, src_len); memcpy; return n`（0x4010 `csel x19, x1, x3, lo`），与 keymaster.img 的 0x4ace0 同 idiom。dispatcher、provisioning、SPU 响应路径全部经它。
- **读路径 0xea0**：key_tag 白名单仅两个 magic（"TSID"=0x44495354 → 'sp_keymint_device_id'，"STTA"=0x41545453 → 'sp_keymint_attest_key'，0xef4-0xf24）；存储返回的 data size 与 NS buffer 长度比较（0x101c-0x1024 `cmp x2,x21; b.ls`，否则 'buffer too small : data size %d!'）。有界。
- **写路径 0x167c**：同两 tag 白名单 + `is_reprovision_allowed`（0x2210：读 'sp_keymint_prov_lock_status' + `qsee_cfg_getpropval` 读 allow_reprovision_* 属性）+ 已 provision 拒绝（'%s: key_tag 0x%x is already provisioned'）。
- **SPU 透传 0x251c/0x3090**：响应头 magic 校验（[sp,#4]=="succ"=0x73756363）；SPU 给的 payload_len 双重限界——对共享 buffer 大小（0x3130-0x3144，否则 'Response is too long: %u'）再对 NS 输出 buffer（0x25dc `cmp x3,x20; b.ls`，否则 'Response buffer is too short (%u < %u)'，**注意：此分支返回成功码 0 但不拷贝**，属小逻辑瑕疵非内存问题）。
- **0x3228 的 NS 字符串处理**：对 NS 字符串做 `strlen`（0x50a0）+ strtok 式切分（0x510c，"8:d47728cf3e4481,..." 格式）+ 按 strlen 结果 malloc/memcpy。若 NS buffer 内无 NUL，strlen 越出映射区——但越界读落在 **NS 自有内存**（TA 仅映射了 NS 提供的 buffer），泄露去向是发给 SPU 的命令而非回 NS；另有 `strb wzr, [x0+x_len]`（0x3338）向 NS buffer 末尾写 0。风险低（NS 自我伤害/DoS）。
- **CBOR**：用的是 QCBOR 库（UsefulInputBuf 游标跟踪），`deserializeClientAttestKey`（0x7e78）解析的是 **keymaster TA 的响应**（TA↔TA，半可信），不直接暴露给 NS。
- **未发现 OOB 读/信息泄露原语。** 与 keymaster.img 相比攻击面更窄：无秘密派生、无秘密回传路径。设计上唯一敏感流是 attestation 私钥 provisioning（keymaster → 本 TA → SPU，`get_eccPrivate_key_asn1_der` 0x7b94），但内容不经 NS 控制也不回 NS。

## 6. strongbox RKP 实际位置（结论 + 证据）

**strongbox CSR 的 CDI_Leaf 既不在 keymaster.img 的已知全局（那是 default KeyMint 的），也不在 spuservice.img。**

证据链：
1. CSR 对比（`csr_samples/`）：
   - `csr_1.b64`（default）：DICE 链 3 级，叶子/CDI 公钥 = `e63af59f80803921…` == `cdi_leaf_pub.bin` == keymaster.img `base+0x67741`（见 keymint_cdi_analysis.md §3）。
   - `csr_strongbox.b64`：**链长 1**（UDS 自签单证书），UDS 公钥 = 叶子公钥 = `1bfb16f3df26eaf9…`——一个完全独立的 RKP 实例，自己的 UDS/CDI。
2. spuservice.img 无 RKP/CSR/CDI/UDS/seed/BCC/DICE 字符串，无加密导入，无软件加密常数（§2/§3）。
3. tz.img（QTEE core，单 ELF、无内嵌 TA 镜像）含 strongbox 支持胶水但无 RKP 种子 label：
   ```
   'sbservice'                                    @tz+0x1905f5 区域（SPU strongbox 服务名）
   'OEM_ese_strongbox_base_key_reprovisioning_allowed'
   'OEM_ese_strongbox_provisioning_allowed'
   'OEM_ese_strongbox_bypass_rot_binding' / 'ese_rot_binding'
   'SharedKeyRoot' / 'SharedKeyHmac' / 'SharedKeyIDP'
   'BCC QTEE Library Error: ret = %d'             ; QTEE 内置 BCC(DICE) 库
   GUID 05B04A44-BF30-42DF-9E2F-B366B980ED19
   ```
4. spuservice.img 的角色由自身字符串钉死：把 keymaster TA（'sp_keymaster'，CKMHal/IKMHal_*）的 attestation key / device ID / auth token key / PSK / shared-secret-nonce 经 spcom（`qsee_spcom_client_send_message_sync`，通道 'spu_service'）**灌入 SPU**——即 SPU 是接收 secrets 的对端，strongbox KeyMint 运行于 SPU 之上。

**指向：strongbox KeyMint（含 1bfb16f3 对应 CDI_Leaf 的派生与存放）在 SPU 固件内。** 该固件不在当前 dump 集（`firmware/` 只有 abl/keymaster/spuservice/tz/xbl，均无 'RKP PRIVATE KEY SEED'）。建议下一步：
- 从设备 dump SPU 固件分区（SM8750 上 SPU 固件可能为独立分区/mbn，或经 XBL 加载；tz.img 的 'sbservice' 与 OEM_ese_strongbox_* 属性是 QTEE 侧入口点）；
- 运行时路径：hook spuservice.img 的 spcom 发送点（`qsee_spcom_client_send_message_sync`，veneer 0x130，GOT `base+0xf0a0`）可观察 NS→SPU 的全部 provisioning 流量；strongbox CSR 触发（`cmd remote_provisioning csr strongbox`）若经 SPU 内部处理则不在 TZ 侧留痕，若经 QTEE 'sbservice' 中继则可在 tz.img 的 BCC 库打点开挖。

## 7. 附：本镜像 hook 点（如需观测 provisioning 流）

文件偏移 = vaddr + 0x1000；base = 运行时加载基址。

- spcom 发送（所有 SPU 流量必经）：va 0x29b0 函数 `send_msg_to_spu` 内 `bl #0x130`（qsee_spcom_client_send_message_sync，'qsee_spcom_client_send_message_sync() ret [%d]' 日志点前）。
- SFS 读（provisioning 数据回读）：va 0x17fc `read_data_from_sfs`。
- attest 私钥过手点：`get_eccPrivate_key_asn1_der`（0x7b94，'IKMHal_getEccprivKey_der failed: %d'）返回处——keymaster 的 ECC attestation 私钥 DER 经此流向 SPU。
