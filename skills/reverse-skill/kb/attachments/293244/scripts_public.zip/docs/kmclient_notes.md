# kmcli — KeyMint TA 直连客户端：通道笔记

设备：Lenovo TB322FC / SM8750P / Android 16 / KernelSU root（u:r:ksu:s0）
日期：2026-10-09。工具：`kmcli/kmcli.c` → `kmcli/kmcli`（aarch64）。

## 1. 通道结论：已打通

**可用路径 = 复用 HAL 自己的传输：`KeymasterUtils`（/vendor/lib64/libkeymasterdeviceutils.so）。**

```
kmcli <cmd_id_hex> [payload_hex] [mode]
#   mode: ku (默认, 可用) | shim | raw
# 例:
#   kmcli 200                          # GET_VERSION
#   kmcli 311f a10450<32hex>           # GET_ROOT_OF_TRUST, {4: h'challenge16'}
#   kmcli 219                          # GENERATE_FRS_AND_UDS（空 payload 读取路径）
#   kmcli 3126 a1183700                # GENERATE_RKP_HMAC mode 0
```

设备上无 /dev/qseecom，只有 /dev/smcinvoke。协议栈（全部真机验证）：

- `libQSEEComAPI.so` 在本平台是 **QSEECOMPAT shim**，架在 MINK IPC（libminkdescriptor.so）+ dmabuf heap "qcom,qseecom" 上。
- `QSEECom_start_app(&h, "/vendor/firmware_mnt/image", "keymaster64", size)` **可用**（TA app name = **"keymaster64"**，来自 keymaster.img TA_APP_NAME @0x65018 → 0x65000 "keymaster64"，TA_METADATA 亦含 `n=keymaster64`）。
  - handle 布局（0x48B）：+0x00 sb(dmabuf mmap)，+0x08 sb_len，+0x0c fd，+0x18 invoke_fn，+0x20 object（FdWrapper @ heap），+0x38 state(=2)。
  - 进程 fd 表出现 `anon_inode:qtee-41`（= smcinvoke 会话）+ dma_heap fd。
- **但 shim 的 `QSEECom_send_cmd` 对该 object 失败**（logcat: `QSEECOMPAT: QSEECom_send_cmd: Error -1`）；直接对该 object 做 MINK `invoke(obj, op=0, {cmd,rsp}, counts=0x11)` 也返回 `Object_ERROR_INVALID(2)`。该 object 是 IAppController 系（见 §3），op 0 不是 sendCommand。
- **真正可用的发送方式**（照抄 HAL：libkeymasterdeviceutils `KeymasterUtils::send_cmd` @0x7afc）：
  - HAL 自己的 MINK 链：TZCom_getClientEnvObject → TimedRetryForwarder_new → 打开服务（UID 0x97/0x96）→ 拿到 app object（存 ctx+0x20/+0x28），`invoke(obj, op=0, { {cmd,len}, {rsp,len} }, counts=0x11)`，**buffer 是普通 malloc(0xa000)，rsp = 独立 buffer**。
  - kmcli ku 模式：dlopen libkeymasterdeviceutils.so，调 `KeymasterUtils::KeymasterUtils(TEE=1)`（`_ZN14keymasterutils14KeymasterUtilsC1E26keymaster_security_level_t`）+ `send_cmd`（`_ZN14keymasterutils14KeymasterUtils8send_cmdEPvjS1_j`）。一次成功。

- SELinux：ksu root 域未被拦（无 avc denied），未动 setenforce。

## 2. TA 命令线格式（keymaster.img 实证）

TA 入口链：CElfFile_invoke @0x4a680（op==0 且 **counts==0x1200**，args[0]=req, args[1]=rsp）→ 0xe578 → 0xe158：
- 请求：**LE32 cmd_id || payload**（小端！0xe1ec-0xe208 的 bfi 序列证明 LE）
- 响应：**LE32 retcode || LE32 payload_len || payload**（0xe2e4-0x310 的 strb 序列证明 LE）
- 错误时 payload_len 字段不可靠（常为 buffer 剩余容量 0x9ff8），只看 retcode。

## 3. MINK/QTEE 对象模型（本次逆向确认）

- `ObjectCounts_pack(BI, BO, OI, OO)` = BI | BO<<4 | OI<<8 | OO<<12；错误码：0 OK, 1 ERROR, 2 INVALID(op/counts 不符), 3 SIZE_IN...
- IAppLoader: loadFromBuffer=0 / loadFromRegion=1 / loadEmbedded=2 / connect=3 → 返回 IAppController。
- IAppController: openSession=0 / unload=1 / getAppObject=2 / installCBO=3 / disconnect=4 / restart=5。
- 我们经 shim 拿到的 object 用 op0+0x11/0x424 都是 INVALID(2)；HAL 的 object（服务 UID 0x97/0x96 开出）op0+0x11 可用。
  差异原因：两者是不同接口对象。kmcli 直接用 HAL 的 KeymasterUtils 绕过此问题。
- 参考：qualcomm/minkipc（github），libminkadaptor/tests/smcinvoke_client/idl/*.idl。

## 4. 实测结果

### 4.1 GET_VERSION (0x200) —— 通道基准
```
retcode=0, payload=03 00 00 00 05   （KeyMint v3, subversion 5?）
```

### 4.2 KEYMINT_GET_ROOT_OF_TRUST (0x311f) —— 只读，正常
请求 = CBOR `{4: h'<16B challenge>'}`：
```
kmcli 311f a1045000000000000000000000000000000000
→ retcode=0, 127B: {36: h'...'}（含 VB key digest 5820…、boot state a10105…）
```

### 4.3 KEYMINT_GENERATE_FRS_AND_UDS (0x219) —— ★ 大新闻：通道成立
```
kmcli 219            # 空 payload
→ retcode=0, payload_len=32:
  20000000 4636a15bf17299f51acb978c9dbde7d9 48176c5376e139eb167780ab
```
- **两次独立进程调用返回完全相同** → 确定性（KDF 派生，非 RNG）→ 是 FRS 类派生物，不是新 UDS。
- 空 payload 走 handler 0x2a284 的 `x1 != 0x2c` 分支（0x2a410，读取/默认路径），**provisioning 门（f2 → 0x212c4）没有拦截**。
- 结论：**NS 世界可直接从 TA 读出 32 字节 SHK 派生秘密（FRS），无门槛**。审计预测（"量产机预期被拒"）被推翻——该设备上 0x219 完全开放。
- 注意：FRS（"KM RANDOM NUMBER KEY SEED" KDF）≠ CDI_Leaf（"RKP PRIVATE KEY SEED" KDF），但同一 KDF 机制（veneer 0x230）。这证明 NS←TA 秘密回传通道存在。
- 未测试 0x2c 字节的写入/生成路径（会写全局 flag 0x6767c/0x67680，遵守不动状态原则）。空 payload 路径是否置位 flag 未完全排除（0x2a830 在另一分支）。

### 4.4 KEYMINT_GENERATE_RKP_HMAC (0x3126) —— oracle 部分验证
- 空/乱 payload → retcode -1（CBOR 解析失败）。
- `{55: 0}`（`a1183700`）→ **retcode=0, 375 字节结构化响应**：
  - key 23: bstr = `["KMKD" magic, 0x500000001(版本), 时间戳, 设备信息map(os/patch level 等), [bstr64 sig, bstr12 nonce, bstr32, bstr16]]`
  - key 63: bstr = **COSE_Mac0**：[protected={1:5(HMAC-256)}, nil, COSE_Key(P-256, -2=x, -3=y), **bstr32 tag**]
  - 即 TA 用 SHK 派生的 RKP HMAC key（全局 0x67790）对 COSE key 做 HMAC-SHA256 返回 tag —— **oracle 工作正常**。
- `{55: 1}` → -12；`{55: [h'ABC']}` / `{55: [自制 COSE_Key]}` → -1。label 55 更像模式/计数选择子而非任意数据数组；任意数据的 MAC 需要正确的 key 编码格式（待逆向 deserialize 0x37470 的字段语义，或从 keymint-service-qti 的 generateRkpKey 抓真实请求）。
- 旁证：libkeymasterutils.so 内含完整纯软件 RKP 栈（PureSoftRemoteProvisioningContext::GenerateBcc/DeriveBytesFromHbk/GenerateHmacSha256）——SW 回退路径的 NS 侧实现就在 HAL 库里。

### 4.5 其他探测
- 0x21001/0x21002/0x21003 → -1；**0x21004 → retcode 0**（无 payload；QTI 厂商命令，handler 0x6640，疑 keymint_get_heap_info 类，值得后续用正确参数试）。
- 0x311f 空 payload/错误格式 → -1（格式校验生效，CBOR map label 4 = challenge）。

## 5. 编译配方（Windows + LLVM，无 NDK）

```
MSYS_NO_PATHCONV=1 D:\ProgramFiles\LLVM\bin\clang.exe \
  --target=aarch64-linux-android33 -O2 -fPIE -pie -ffreestanding -fno-stack-protector \
  -nostdlib -o kmcli kmcli.c vendor_libs/libc.so vendor_libs/libdl.so \
  -Wl,--dynamic-linker,/system/bin/linker64 -Wl,-e,_start
```
要点：
- 无 NDK 头文件：手工声明 printf/malloc/dlopen 等。
- 无 crt：自带 `_start`（naked asm）→ `__libc_init(sp, NULL, slingshot, &structors6zero)` → `exit(main(...))`。
- **必须 `export MSYS_NO_PATHCONV=1`**，否则 Git Bash 把 `/system/bin/linker64` 改成 `C:/Program Files/Git/...`（第一次失败的坑）。
- push 后必须 `chmod 755`（adb push 默认 640）。

## 6. 后续

- 0x3126 请求格式精确化：逆向 TA deserialize @0x37470（label 55 语义、[x20+0x574]==4 / +0x55c / +0x540 必填标记），或 hook keymint-service-qti 抓包。
- 0x21004 厂商命令定性（可能 heap info → 堆 grooming 辅助）。
- 堆残留泄露 fuzz 现在有了发射台：任意 cmd + 任意 payload 都能发（ku 模式）。
- 注意纪律：generate_key(0x3108)/import/upgarde/set_boot_state/FBE_SET_SEED 等会写状态，未经确认不要发。
