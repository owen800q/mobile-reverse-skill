# XBL / imagefv 验签链分析 — CVE-2026-25302 可利用性评估

- 目标固件: `live_dump/pdump/`（Lenovo TB322FC / SM8750P, Android 16, patch 202606，与运行设备字节一致）
- 工具: 新增 `disasm_tmp/xbl_parse.py`、`disasm_tmp/xbl_build_db.py`、`disasm_tmp/xbl_sfind.py`、`disasm_tmp/xbl_dis.py`；db 在 `disasm_tmp/db_xbl/`（XBL A64 主体：147456 指令 / 1688 字符串 / 1013 字符串 xref）
- 地址约定: XBL A64 虚拟地址（加载基址 0x14800000 系，见 §1）

## 1. xbl_a.img 真实格式（三段拼接 ELF，与任务书"ELF32 RISC-V"第一印象不同）

xbl 分区 = **三个首尾相接的独立 ELF**（与 firehose programmer 的 melf 同构）：

| 文件偏移 | 格式 | entry | 内容 |
|---|---|---|---|
| 0x0 | ELF32 **RISC-V** (mach=0xf3) | 0x22126000 | TME SRAM stub（2 个小 LOAD，0x600+0x280B） |
| 0x904 | ELF32 RISC-V | 0x20415100 | **TME 固件**（12 phdr；代码 0x20415100+0x207e8；hash 段 @+0x2b000 sz 0x2c70） |
| 0x2e574 | **ELF64 AArch64** | 0x14825fa8 | **XBL 主体**：RX 0x14825000+0x90000，R 0x148b5000+0x13000，RW 0x148cb000+0x39000 / 0x14904000+0x14000；hash 段 @文件 0x12f574 sz 0x2be0 |

即：头部 RISC-V 只是 TME 容器；真正的 XBL 是 A64。启动链：**PBL → TME(RV32，验签并加载 XBL；含 `ImageAuthPblUtils.cpp`、`tme_tz` 字符串) → XBL(A64)**。

## 2. 各镜像签名状态实测（逐一解析 hash 段）

| 分区 | 格式 | hash 段 | 内嵌证书链 | 结论 |
|---|---|---|---|---|
| tz_a | ELF64 | @0x3f7000 sz 0x37c8 | 12 张 X.509 | **已签名** |
| hyp_a | ELF64 | @0x1a7000 sz 0x2e14 | 12 | **已签名** |
| abl_a | ELF32 容器(FV+LZMA+PE) | @0x3a000 sz 0xf38 | 6（LENOVO+QC SecTools） | **已签名** |
| keymaster_a | ELF64 (QSEE TA) | @0x6e000 sz 0x1058 | 6 | **已签名** |
| devcfg_a | ELF64 | @0xd000 sz 0x1228 | 6 | **已签名** |
| featenabler_a | ELF64 | @0x17000 sz 0x2be0 | 12 | **已签名** |
| **xbl_config_a** | ELF64 (CFGL, entry 0x1494e000) | @0x53000 sz 0x1520 | 6 | **已签名**（任务书"非 ELF"判断有误） |
| **imagefv_a** | ELF32 容器（FV+LZMA） | @0x81000 sz 0xf38 | 6（与 abl 同链） | **已签名**，但内容不是摘要表（§3） |
| **ddr** | **raw data**（非 ELF，头 `00000000 1e000000`，有效 0x32fa2B） | 无 | 无 | **未签名** |
| **cdt** | raw —— **live dump 全零** | 无 | 无 | **未签名/可空** |
| **tzsc** | raw —— **live dump 全零** | 无 | 无 | **未签名/可空** |

## 3. imagefv 的真实角色（决定性发现）

imagefv_a LOAD 段是 UEFI FV（`_FVH` @0x1028），LZMA GUID 节解压出 **31MB 嵌套 FV**，内容为 **13 张 BMP**（battery_symbol_*.bmp / main_logo*.bmp / tsens_thermal_*.bmp —— ABL 充电/低电界面资源）：

```
FFS 3E5584ED… 'battery_symbol_Soc10.bmp'   FFS 57F89E48… 'main_logo1.bmp' (12MB)
FFS E2EA5A4F… 'tsens_thermal_symbol.bmp'   …
```

**本设备的 imagefv 分区不含任何镜像摘要表**——Lenovo 把它复用为显示资源库。XBL 代码中也无任何 "imagefv" 字符串引用。结论：**XBL 不通过 imagefv 摘要验证 tz/keymaster**，每镜像靠自身 hash 段+证书链做 SecBoot 认证。

## 4. XBL 验签调用链

代码模块（字符串证据）：`boot_elf_loader.c`(0x14846bc8+)、`boot_elf_driver.c`、`boot_elf_auth.c`(0x14849038-0x14849334)、`boot_seclib_s.c`(0x1484ab74-0x1484b168，含 "Auth Metadata" @0x1484abd0、"Segments hash check" @0x1484afd0)、`boot_whitelist_prot.c`(0x1482bf58+，白名单项 tag 0x574c5354)、`boot_mbn_loader.c`、`boot_process_config_context.c`(0x1484dd80+，" Image Load, Start" @0x1484e1e8)。

**镜像装载配置表** @0x148ce9c8（步长 0x88，19 项，{name, type, secboot_id, flags, hooks}）：

```
APDP(type 0x1c,sb 0x25)  XBL Config(0x18,sb 0x20)  SHRM(0x4,sb -1)  CDT(0x7,sb -1)
DDR(0x1d,sb 0x42)  RamDump(0x2,sb 0x3d)  AOP Config(0x1,sb 0x21)  AOP(0x2c,sb 0x89)
SOCCP_DEBUG(0x2d,sb 0x8a)  SOCCP_DCD(0x31,sb 0x9c)  PDP_CDB(0x2e,sb 0x91)  PDP(0x5,sb 0x64)
CPUCP_DTB(0x6,sb 0x31)  CPUCPFW(0x13,sb 0x5)  QSEE Dev Config(0x12,sb 0x7=devcfg)
QSEE(0x17,sb 0x2b=tz)  SEC(0x11,sb 0x15)  QHEE(0x1b,sb 0x9=hyp)  APPSBL(0x21/0=abl)
```

要点：
- **表内无 keymaster、无 imagefv** —— XBL 启动时不装载 keymaster 分区。keymaster_a 是 QSEE TA（ET_DYN + QSEE veneer，见 keymint_cdi_analysis.md），由 **TZ/QTEE 在 Android 运行时按需装载并验签**，与 XBL/本 CVE 无关。
- CDT/SHRM 的 secboot id = 0xffffffff（**设计上不验签**）；DDR id=0x42 但 ddr.img 无任何签名结构 → 实际不验。
- tz(QSEE)/hyp(QHEE)/abl(APPSBL)/devcfg/xbl_config 均走 boot_elf_auth → seclib（hash 段 + 证书链 + fuse 根哈希）。

## 5. CVE-2026-25302 可利用性判定

CVE 机制（"非 ELF 分区处理时认证/签名被绕过"）在本设备的映射：**只有 ddr / cdt / tzsc 三个分区是非 ELF 且不被验签**（cdt/tzsc 在 live dump 中全零仍正常启动，实证无校验；cdt 仅有 'eCDT Checksum mismatch' 软校验，DDR 训练数据无签名结构）。

对目标"让改过签名的 keymaster.img 启动"的三条候选路径判定：

| 路径 | 判定 | 原因 |
|---|---|---|
| (a) 改 imagefv 摘要放行改过的 keymaster/tz | **不可行** | imagefv 无摘要表（BMP 资源）；且 imagefv 本身有签名 |
| (b) 改 xbl_config 关验签 | **不可行** | xbl_config 是带证书链的签名 ELF（hash 段 @0x53000），篡改即 SecBoot 失败 |
| (c) 非 ELF 注入（ddr/cdt/tzsc）直取代码执行 | **不能直接达成** | 三者均为纯数据，XBL 不执行其内容；tz/hyp/abl/keymaster 全是签名 ELF，把 tz 分区换成非 ELF blob 只会 ELF 头解析失败 → boot 失败，不存在"非 ELF 就裸跳到镜像"的回退路径（QSEE 类型的入口来自 ELF header） |

**总判定：CVE-2026-25302 在本设备上不能单独达成"未签名 keymaster/tz 启动"。** 它的实际攻击面是 **XBL 对未认证数据的解析器**：
- `sbl1_load_ddr_training_data`(0x148268f4) + DCB/DTB 解析（'boot_pre_ddr_dtb_load'、xbl_config 内的 DDR 配置），在 **EL2/A64、tz 装载之前** 运行；
- CDT/eCDT 解析（'boot_cdt_init' 0x148b6957，校验和仅防误不防攻击）。

若在这些解析器中找到内存破坏漏洞，则链为：改 ddr.img（root dd 可写）→ XBL 上下文代码执行 → 关/绕 tz 验签 → 改装过的 tz → TZ 内关掉 QTEE TA 验签 → keymaster.img 被替换的 TA 装载。这是"解析器 0day + CVE 提供的未认证投递面"的组合，而非 CVE 单独可用。

## 6. 建议的设备侧验证（dd 直写，廉价且决定性）

1. tz_a 翻 1 字节 → 预期 boot 失败/进 9008（证实 tz 验签生效）；
2. ddr.img 翻 1 字节 → 预期正常启动或 DDR 重训（证实 DDR 分区无验签 = CVE 面存在）；
3. cdt/tzsc 写任意值 → 预期正常启动（已间接证实：dump 全零）；
4. imagefv_a 翻 1 字节 → 预期 boot 失败（证实 imagefv 虽无摘要角色但仍被 SecBoot 验签）。

## 7. 复现

```
venv/Scripts/python.exe disasm_tmp/xbl_parse.py            # 三段 ELF + 各镜像 hash 段/证书解析
venv/Scripts/python.exe disasm_tmp/xbl_build_db.py         # 建 db_xbl（A64 反汇编+字符串 xref）
venv/Scripts/python.exe disasm_tmp/xbl_sfind.py whitelist  # 字符串/xref 查询
venv/Scripts/python.exe disasm_tmp/xbl_dis.py 1484aaa0 0x200
```
