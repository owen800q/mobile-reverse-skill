# KeyMint TA (keymaster.img) — RKP CDI_Leaf 定位分析

- 目标固件: `firmware/keymaster.img` (SM8750P / Snapdragon 8 Elite, Android 16, OPD2413_16.0.8.300)
- 工具: capstone 线性反汇编 + ADRP/ADD 字符串 xref（脚本在 `disasm_tmp/`: `elf_parse.py`, `build_db.py`, `fdump.py`, `sfind.py`, `blxref.py`, `funcinfo.py`）
- 所有地址为 ELF 虚拟地址（vaddr）。**文件偏移 = vaddr + 0x1000**（对所有 LOAD 段成立）。

## 1. ELF 结构

ELF64 / AArch64 / ET_DYN / 无 section header（`e_shoff=0`），入口 0。文件 512KB，LOAD 段之后拼有哈希段（phdr[8] NULL, off 0x6e000, size 0x1058），剩余到 0x80000 为签名/填充。

| phdr | 类型 | 文件偏移 | vaddr | filesz | 权限 |
|---|---|---|---|---|---|
| 1 | LOAD | 0x1000 | 0x0 | 0x6459c | R-X（代码+rodata） |
| 2 | LOAD | 0x66000 | 0x65000 | 0xfc | RW |
| 3 | LOAD | 0x67000 | 0x66000 | 0xb90 | RW（GNU_RELRO, GOT——文件中全 0，loader 重定位填充） |
| 4 | LOAD | 0x68000 | 0x67000 | 0x1bb4 | RW（**关键全局变量区**） |
| 6 | LOAD | 0x6a000 | 0x69000 | 0x3acd | RW（含 DYNAMIC） |

前 0x300 字节是 veneer 表（`adrp x16,#0x66000; ldr x17,[x16,#off]; br x17`，经 GOT 间接到 QSEE 系统服务）：
- `0x20` = 日志；`0x40` = TA 信息；`0xb0` = RNG（返回写入字节数）；`0x230` = **HW crypto SHK KDF**（见 §2）；`0x240` = SFS 读写等。

## 2. HW crypto SHK KDF（一切派生的根）

veneer `0x230` 签名（从两处调用点交叉确认）：

```
kdf(ctx_or_0, in_len, label1, label1_len, label2, label2_len, out, out_len)
```

调用点 A — `0x1a438`（包装器，重排参数后 `bl #0x230`）：
```
0001a49c: csel x0, x0, xzr, eq   ; ctx 或 NULL
0001a4a0: bl   #0x230
```

调用点 B — `derive_device_private_key` 内直接调用（**CDI_Leaf 派生点**）：
```
0003f960: ldr  w1, [sp, #0x48]
0003f968: ldr  x6, [sp, #0x40]        ; out = 堆 buffer
0003f970: add  x2, x2, #0x2c5         ; "RKP PRIVATE KEY SEED"
0003f974: mov  w3, #0x15              ; len 21
0003f978: add  x4, x4, #0x2da         ; "Device Key Seed"
0003f97c: mov  x0, xzr                ; ctx = 0 → 直接从 SHK 派生
0003f980: mov  w5, #0xf               ; len 15
0003f988: bl   #0x230                 ; ← CDI_Leaf 诞生的指令
0003f98c: cbz  w0, #0x3f9ac           ; 成功
```

## 3. CDI_Leaf 定位结论（核心）

**CDI_Leaf = 32 字节 Ed25519 种子，KDF(SHK, "RKP PRIVATE KEY SEED" / "Device Key Seed")，运行时固定在全局 `base + 0x67761`；其 Ed25519 公钥在 `base + 0x67741`；初始化标志 `base + 0x67740`（1=已派生）。**

证据链（`derive_device_private_key` = 函数 `0x3f7b4`，字符串 0x612ab 'derive_device_private_key'，调用者：`generateBcc` 0x424d0 和 `sign_in_sw` 0x480f4）：

a) 派生后写入 0x67761 并持久化到 SFS 对象 "DK_PRIV"（字符串 0x6114b）：
```
0003f9bc: add  x1, x1, #0x761   ; x1 = 0x67761
0003f9d4: bl   #0x403b0         ; set key object
...
0003fb38: adrp x0, #0x67000
0003fb40: add  x0, x0, #0x761   ; dst = 0x67761
0003fb44: mov  w1, #0x20
0003fb48: mov  x2, x21          ; src = DK_PRIV 堆 buffer
0003fb4c: bl   #0x4ace0         ; memcpy → 0x67761
0003fb84: add  x0, x0, #0x14b   ; "DK_PRIV"
0003fb88: add  x1, x1, #0x761   ; 0x67761
0003fb8c: bl   #0x3fbf0         ; SFS 写 ("DK_PRIV", seed)
```

b) 0x67741 是由 0x67761 派生的 Ed25519 **公钥**（`0x3f648` = ED25519_derive_public_key，字符串 0x61111，内部 veneer `0x4b0` cmd=4 导入私钥 / cmd=7 导出公钥）：
```
0003fad4: add  x20, x20, #0x741   ; 0x67741 (pub out)
0003fad8: add  x2, x2, #0x761     ; 0x67761 (priv in)
0003fae8: bl   #0x3f648           ; ED25519_derive_public_key
```

c) 缓存命中路径（flag 0x67740 置位后直接返回两个全局的指针+0x20）：
```
0003f850: ldrb w8, [x22, #0x740]  ; flag 0x67740
0003f854: tbz  w8, #0, #0x3f8a8
0003f860: add  x9, x9, #0x741     ; pub
0003f86c: add  x10, x10, #0x761   ; seed
0003f870: stp  x9, x8, [x19, #0x18]
0003f878: stp  x10, x8, [x19, #8]
```

d) 重启后从 SFS 恢复：读 "DK_PUB"(0x61144)/"DK_PRIV"(0x6114b) → 填回 0x67741/0x67761（`0x3f8c8-0x3f8e4`、`0x3fa80-0x3fa90`，读函数 `0x40acc`/`0x40b74`）。

与参考实现 `google-rkp-sw/rkp_sw.py` 一致：CDI_Leaf 种子即 32 字节 Ed25519 私钥种子，CSR 中 UDS/CDI_Leaf 公钥由它派生。

## 4. KEYMINT_GENERATE_CSR_V2 流程

`generateCsrHandler` = 函数 `0x43414`（字符串 0x61bb3；FIXED 变体用 `0x439d4` 区域 = generateCsrHandler_FIXED）：

```
0x43490  bl #0x44468   deserializeGenerateCsr    ; 解析请求到 x29-0xe0
0x434b8  bl #0x42484   generateBcc               ; 构建 DICE/BCC 链（无条件走本地派生！）
0x434e8  bl #0x43590   generateCsr               ; 组装 CSR（cbor_encode_csr_payload 0x46170 等）
0x43518  bl #0x44a04   serializeGenerateCsr
```

`generateBcc` (`0x42484`)：第一步就 `bl #0x3f7b4`（0x424d0）派生/加载 CDI_Leaf 种子 → CBOR 组装（`0x4dfbc` 建 encoder，`0x4e120` 加 tstr "QUALCOMM"(0x61bfc)/"RKP Device Key"(0x61bed)，`0x4e034` 加 bstr）→ 产出 UDS 证书链。

另有 `0x47040`（get/generate DICE chain，供 cbor_encode_csr 经由 0x47718/0x47f08 调用）按 force_sw_dice 二选一：
```
0004706c: bl   #0x47fd4     ; is_hw_dice = (force_sw_dice_prop == 0)
00047070: tbz  w0, #0, #0x47098
00047074: bl   #0x335b4     ; HW: CrkpBCC_UID BCC service
...
000470ac: bl   #0x42484     ; SW: generateBcc（本地种子）
```
链长度缓存于全局 `0x677f0`（0x47208 str / 0x47328 ldr）。

## 5. RKP HMAC key（CSR 的 COSE MAC 密钥）

`calculateCosePublicKeyMac` = 函数 `0x43c18`（字符串 0x61eb4；即 KEYMINT_GENERATE_RKP_HMAC 的处理核心，含 'RKP compute context is null' 日志）：

```
00043c50: ldrb w8, [x22, #0x788]  ; 一次性标志 0x67788
00043c54: tbnz w8, #0, #0x43ca8
00043c60: add  x19, x19, #0x790   ; 全局 key struct 0x67790
00043c70: mov  w0, #0xa           ; key type 10 = RKP HMAC
00043c78: mov  w2, #0x20
00043c7c: bl   #0x86f8            ; derive_hw_key(10, 0x67790, 0x20)
```

**RKP HMAC key（32B）缓存于全局 `0x67790`**（struct：key@+0，len@+0x40），标志 `0x67788`。

`derive_hw_key` (`0x86f8`/switch 在 `0x8700`) 类型表（跳转表字节表 @0x527a9）：
case 0=KM CPHR, 1=KM HMAC, 3=GK HMAC, 4=**测试 override（见 §7）**, 5=KM UNIQUEID, 6=KM DEVICEID, 7=Pre Shared Secret, 8=KM FILENAME, 9=KM ICE, 10=RKP HMAC。
case 10 证据：
```
00088b8: adrp x3, #0x52000 → "KM RKP HMAC HW Crypto key derived from SHK"
00088bc: adrp x1, #0x52000 → "KM RKP HMAC HW Crypto Derived Key"
00088d0: ... bl #0x1a438 → veneer 0x230（SHK KDF，输出到调用者 buffer）
```
RKP HMAC 派生**没有** override 分支，只能走 SHK。

## 6. force_sw_dice 结论

- 属性读取：`get_force_sw_dice` = `0x1bbb4` → `0x1bc14`("force_sw_dice", &val)（经 veneer `0x2c0` 读配置属性）。**读取失败时默认写 0**（0x1bc00 `str wzr, [x19]`）。
- 唯一消费点：包装器 `0x47fd4`，返回 `(val == 0)`：
```
00048000: bl   #0x1bbb4
00048014: cmp  w8, #0
00048018: cset w0, eq        ; val==0 → 1 = HW DICE
```
- 三处使用 `0x47fd4`：`0x4706c`（DICE 链来源）、`0x472e0`（链长度）、`0x48074`（`sign_sig_structure` 0x48040：HW→BCC 服务 `0x33cbc`，SW→本地种子签名 `derive_device_private_key`+`0x3fcf4`）。
- **不是固定/测试种子**：SW 路径用的就是 SHK 派生的 CDI_Leaf 种子（0x67761），与 HW 路径同源；force_sw_dice=1 只是强制在 TA 本地构建 DICE 链并用设备密钥签名。
- **注意**：`generateCsrHandler` 的 `generateBcc` 调用（0x434b8）**不检查** force_sw_dice——CSR 流程必然触发 CDI_Leaf 派生并填充 0x67741/0x67761/0x67740。

## 7. 附带发现：key type 4 测试 override

`0x8574`（被 `0x8064` = get_hmac_session_key 路径调用）把调用者给的 key 拷入全局 `0x674b8` 并置 `0x67518`=1；`derive_hw_key` case 4（0x87d4）在输入长 32 且标志置位时直接 `memcpy(out, 0x674b8, 0x20)` 跳过 SHK 派生。type 4 的调用点（0x31fc 等）属于 CKMHal/BCC retain 路径，不影响 RKP HMAC/CDI_Leaf。

## 8. generate_frs_and_uds（UDS 是生成还是读取）

函数 `0x2a284`（v1/v2 字符串 0x5d212/0x5d295）：
- **UDS：生成**——默认 RNG 32 字节（`0x16090` → veneer `0xb0`），见 0x2a8f8/0x2a39c；若输入 blob 头部字段非零则**调用者提供** 0x40 字节（0x2a774 memcpy，测试模式，置全局 `0x67680`=1）。UDS 副本存全局 `0x6765c`（0x2a7e4），标志 `0x6767c`。
- **FRS：派生**——`generate_frs` (`0x2a114`)：`KDF(SHK, "KM RANDOM NUMBER KEY SEED"/"Km random number Key Seed")` 32B（0x2a21c-0x2a240 `bl #0x1a438`），拷给调用者。
- 与 CDI_Leaf 无直接关系。

## 9. 推荐 patch / hook 点

文件偏移 = vaddr + 0x1000。TA 基址记为 `base`（ET_DYN，运行时 = 加载基址 + vaddr）。

### H1（首选，被动）：直接读全局
触发任意一次 GENERATE_CSR_V2（或 RKP_HMAC）后：
- CDI_Leaf 种子：`base + 0x67761`，32 字节（标志 `base+0x67740`==1）
- CDI_Leaf 公钥：`base + 0x67741`，32 字节（可用来校验种子：Ed25519 pub 派生比对）
- RKP HMAC key：`base + 0x67790`，32 字节（标志 `base+0x67788`==1）

### H2（主动）：KDF 返回点抓种子
- va `0x3f988`（文件 `0x40988`）：`bl #0x230`，原字节 `2a 02 ff 97`
- 改法：改为 `bl <trampoline>`；trampoline 先执行原调用（或跳回 0x3f98c），返回后 `ldr x6, [sp, #0x40]`（种子指针）、`[sp,#0x48]`=0x20，把 32 字节拷到约定 scratch 区/日志，再 `mov w0, wzr; b 0x3f9ac`。
- 该点只在首次派生时命中（之后走 SFS/全局缓存），需清 SFS "DK_PRIV" 或在首启时 patch。

### H3（主动，每次 CSR 都命中）：memcpy 入全局点
- va `0x3fb4c`（文件 `0x41b4c`）：`bl #0x4ace0`，原字节 `65 2c 00 94`；此时 x2=x21=种子源、dst=0x67761
- va `0x3fb30`（文件 `0x41b30`）：`bl #0x4ace0`，原字节 `6c 2c 00 94`；公钥 memcpy
- 改法：patch 成跳板，dump x2 指向的 32 字节后执行原 memcpy。

### H4：强制 SW DICE（可选，用于验证）
- va `0x48018`（文件 `0x49018`）：`cset w0, eq`，原字节 `e0 17 9f 1a` → 改 `mov w0, wzr`（`e0 03 1f 2a`）即恒返回 0=SW 路径（DICE 链本地构建、sign_in_sw 本地签名）。
- 或反向 `mov w0, #1`（`20 00 80 52`）恒 HW。
- 等效软方法：把配置属性 force_sw_dice 置 1（无需 patch）。

### 不建议的点
- derive switch case 4 的 override（0x674b8/0x67518）够不到 RKP HMAC（type 10）和 CDI 种子，勿误用。

## 10. 未决 / 后续

- 命令 ID → handler 的分发表在 RELRO 中由 loader 重定位填充（文件内容为 0），未能静态确认 KEYMINT_GENERATE_CSR_V2 → 0x43414 的直接映射；但 0x43414 内部日志字符串 'generateCsrHandler'/'generateCsr'/'deserializeGenerateCsr' 已锚定身份。如需精确命令号，运行时读 `base+0x66000` 起的 GOT/表或 hook 0x43414 入口打印。
- veneer `0x230` 的确切 QSEE 服务号需运行时读 GOT `base+0x66120` 确认（文件中为重定位占位 0）。
- 'RKP Device Key' 证书构建（0x42650-0x42690, CBOR tstr "QUALCOMM"/"RKP Device Key"）在 generateBcc 内，可作为 CSR 中定位 UDS 证书的标志。

---

# Attack Surface（NS → TA 信息泄露原语审计）

## 0. 命令分发表（完整还原）

命令表在 RELRO 全局 `0x66578`，0x60 个条目，每条 16B：`{u32 id, u8 f1, u8 f2, pad[2], u64 handler}`。
handler 指针由 loader 经 R_AARCH64_RELATIVE 重定位写入（RELA @ va 0x69130），**已从 RELA addend 完整还原**；
命令名由 mapper `0x10184`（低 ID）+ 内联第二段（0x104cc 起，name=="INVALID" 时进入）模拟求解。
派发函数 `0xe344`（GPAppLib_handleRequest 内部）：
```
0000e3bc: ldur w8, [x25, #-4]   ; entry.id
0000e3c0: cmp  w8, w19          ; == cmd?
0000e464: ldrb w8, [x25]        ; f1 → 0x10f24 检查（会话/状态）
0000e474: ldrb w8, [x25, #1]    ; f2 → 0x212c4 检查（ provisioning/secure-state 门）
0000e4a0: ldur x3, [x25, #4]    ; handler
0000e4b4: bl   #0x25e0          ; br x16 间接调用
```
f1=1 → 需 `0x10f24` 通过（读全局 0x6751d[i]）；f2=1 → 需 `0x212c4` 通过（置位 0x67611 / veneer 0x400 secure-state，失败返回 -0x2711）。

关键命令（id → handler）：

| id | 命令 | handler | f1/f2 |
|---|---|---|---|
| 0x3108 | KEYMINT_GENERATE_KEY | 0x2e7c8 | 1/0 |
| 0x310f | KEYMINT_BEGIN | 0xb0fc | 1/0 |
| 0x3111 | KEYMINT_UPDATE | 0xb704 | 1/0 |
| 0x3112 | KEYMINT_FINISH | 0xba90 | 1/0 |
| 0x311e | KEYMINT_GENERATE_CSR | 0x4340c | 1/0 |
| **0x3122** | **KEYMINT_GENERATE_CSR_V2** | **0x4734c** | 1/0 |
| 0x3124/0x3125 | GENERATE_CSR_FIXED / _V2_FIXED | 0x43944 / 0x47ad4 | 1/0 |
| **0x3126** | **KEYMINT_GENERATE_RKP_HMAC** | **0x43dd4** | 1/0 |
| 0x311f | KEYMINT_GET_ROOT_OF_TRUST | 0x354b0 | 1/0 |
| **0x0219** | **KEYMINT_GENERATE_FRS_AND_UDS** | **0x2a284** | **0/1（有门）** |
| 0x210b/0x210c | KM_NEW_IMPORT_KEY / EXPORT_KEY | 0x8200 / 0x83b4 | 1/0 |
| 0x3117 | KEYMINT_IMPORT_WRAPPED_KEY | 0x4518c | 1/1 |
| 0x311c | KEYMINT_GET_TIMESTAMP_TOKEN | 0x4542c | 0/0 |
| 0x2118 | KM_NEW_VERIFY_AUTHORIZATION | 0x15dac | 0/0 |
| 0x0202/0x0203 | READ/WRITE_KM_DEVICE_STATE | 0x1de74 / 0x1e1a4 | 0/1 |
| 0x220e/0x220f | KM_NEW_GET_HMAC_SHARING_PARAMS / COMPUTE_SHARING_HMAC | 0x7504 / 0x7678 | 0/0 |

触发方式（授权研究设备）：root shell 经 libqseecom 客户端直接向 KeyMint TA 发命令（GPAppLib_handleRequest @ 0x102b0 是 TA 入口）；
或走 Android 正常栈：keystore2 `generateCertificateRequestV2`（IRemoteProvisioning AIDL，RemoteProvisioningManager）→ 0x3122。

## 1. CSR 路径审计（0x4734c generateCsrHandlerV2）

流程：CBOR 解析（0x4d90c init / 0x4e974 enterMap / 0x4f1d8 GetByLabel）→ 取字段 4（challenge）与 0x39（DeviceInfo bstr）→
0x46100 malloc_csr_payload → 0x46338 build_csr_payload → 0x47040 DICE 链 → 0x481a8/0x47874 cbor_encode_csr → 0x479a4 序列化输出。

长度校验证据（challenge）：
```
0004758c: ldr  x1, [sp, #0x98]   ; challenge len（CBOR 解码器给出）
00047590: cmp  x1, #0x41
00047594: b.hs #0x475c8          ; ≥65 → KM_ERROR(-8)
000475a0: ...  bl #0x45038       ; 按 len 分配（malloc 不清零）
000475ec: ldp  x0, x1, [sp, #0x20]
000475f0: ldp  x2, x3, [sp, #0x90]
000475f4: bl   #0x4ace0          ; 钳制拷贝 min(dst,src)，返回实际字节数
000475f8: ldr  x3, [sp, #0x98]
000475fc: cmp  x0, x3            ; 拷贝数 != 声明 len → 错误
00047600: b.ne #0x47650
```
`0x4ace0` 本身是钳制拷贝：
```
0004acf4: cmp  x1, x3
0004acf8: csel x19, x1, x3, lo   ; n = min(dst_len, src_len)
```
DeviceInfo 字段（0x39）同样走 alloc-exact + 钳制拷贝 + 长度复核（0x47604-0x476a0）。CBOR 解码器 0x4d970/0x4db2c 有 cursor/end 指针跟踪（0x4d99c `ldp x9,x8,[x0,#8]; cmp x9,x8; b.ls err`）。
**结论：CSR 路径未发现 OOB 读。** challenge ≤64B、所有拷贝钳制、输出长度来自 encoder 游标而非请求字段。

## 2. 输入解析（attestation 参数 / CBOR）

GENERATE_KEY(0x2e7c8) → deserialize `0x35cb8`：CBOR map → tag 参数循环（0x36130 parse_one_param，按 tag switch，如 0x300001f4）。
blob 类 tag 存 (ptr,len) 进参数结构（如 0x35e2c `str x8,[x19,#0x5b0]; str x9,[x19,#0x5b8]`），len 由 CBOR 解码器限定在请求 buffer 内。
x509 扩展写入（x509Extensions_writeKeyMint @ ~0x255e0-0x263xx）经 `0x22d54`(开 tag)/`0x22758`(写值)/`0x22da4`(闭合) ASN.1 写入，值来自上述已限界的参数结构。
**未发现长度字段直通 memcpy 的路径。** 注意：证书 buffer 是"先算长度再写入"两遍模式（0x225c0 计算 → 0x1c5d8 malloc → 写入），
若长度计算与写入对攻击者控制的 blob 长度（attestationApplicationId 等）处理不一致，可造成堆溢出写+证书回读泄露——**本次未找到具体不一致点，是最值得继续人工/模糊审计的区域**（0x225c0 长度计算族 vs 0x2266c 写入族）。

## 3. key type 4 测试 override —— 不可用作泄露

- setter `0x8574` 唯一调用点 `0x8064`，位于 `get_hmac_session_key_tee`（'IStrongBox_getHmacSessionKey failed' 0x7fb8 / 'Compution of shared hmac with strongbox failed, use default key derivation' 0x7fe4 所在函数）：
  key 材料来自 **StrongBox TA 的响应**（IStrongBox_getHmacSessionKey），NS 无法直接控制内容；失败回退路径用默认派生。
- 语义是**注入**（把 key 写进 0x674b8），case 4（0x87d4）再把它当"派生结果"拷给 type-4 消费者（0x31fc CKMHal retain 校验、0x15504 等）。
  消费者把该值当 HMAC key 使用，不回显原文。**不构成任意读。**
- 结论：死路（对泄露而言）。若将来能控制 SB 响应或找到直达 0x8574 的命令，它是"伪造派生 key"的注入点，不是读原语。

## 4. GENERATE_FRS_AND_UDS（0x2a284）—— 设计上的秘密返回，但有门

响应中直接包含秘密：
```
0002a890: bl #0x1a438      ; FRS = KDF(SHK, "KM RANDOM NUMBER KEY SEED", 0x20)
...
0002a828: add x0, x8, #8   ; x8 = 响应+4
0002a82c: ldr x2, [sp]     ; FRS buffer
0002a834: bl #0x4ace0      ; memcpy(resp+8, FRS, 0x20)   ← FRS 明文回 NS
```
UDS 来自 RNG（0x16090）或调用者提供（0x2a774 从请求拷 0x40B，测试模式），同样进响应/全局 0x6765c。
门槛：f2=1 → `0x212c4`（provisioning 完成/secure-state 检查后返回 -0x2711）+ 全局 0x6767c/0x67680 一次性标志。
**量产机预期被拒；若目标设备 provisioning 状态异常（或研究机可绕过），这是现成的 SHK 派生秘密（FRS）回传通道——可用来验证 NS→TA 秘密泄露链路，但 FRS ≠ CDI_Leaf。**

## 5. GENERATE_RKP_HMAC（0x43dd4）—— 设计上的 HMAC oracle

handler 解析请求后经 `calculateCosePublicKeyMac`(0x43c18)：
```
00043d1c: ldr w2, [x20, #8]    ; 攻击者数据 len
00043d24: add x4, x20, #0x20   ; 输出 → 请求内偏移（响应）
00043d28: add x3, x3, #0x790   ; key = 全局 0x67790（SHK 派生 RKP HMAC key）
00043d2c: mov w0, #4           ; HMAC-SHA256
00043d34: bl  #0x1a03c
```
对任意攻击者数据返回 HMAC-SHA256(RKP_HMAC_key, data)。f1=1/f2=0，**NS 可达**（RemoteProvisioning 流程正常调用）。
用途：可离线验证/伪造 CSR 的 MAC 字段，但不是内存泄露。

## 6. 其他命令快速结论

- GET_ROOT_OF_TRUST(0x354b0)：固定 0x82 字节结构，memset 后填充，无攻击者长度。干净。
- READ_KM_DEVICE_STATE(0x1de74)：入/出长度均校验 ==0xc。干净。
- GET_TIMESTAMP_TOKEN(0x4542c) / VERIFY_AUTHORIZATION(0x15dac)：token MAC oracle，固定结构。
- BEGIN/UPDATE/FINISH：操作上下文由 0x39d58 解析管理；加解密输出 buffer  sizing 未逐行审完（工作量外），属历史 bug 高发区，列为后续审计项。

## 7. 审计结论（按可行性排序）

1. **没有发现直接的 OOB 读泄露原语**（CSR/解析/x509/ROT/DeviceState 路径均有边界或钳制）。
2. 最接近的三个：
   - **GENERATE_FRS_AND_UDS 设计性 FRS 回传**（若 provisioning 门可过）——证明通道、泄露 SHK 派生物；
   - **GENERATE_RKP_HMAC oracle**（可达）——伪造 CSR 用，不泄露；
   - **x509 证书"算长度→malloc→写入"两遍模式的不一致**（未证实，需 fuzz：attestationApplicationId/DeviceInfo/attestation ids 等可控 blob 的长度边界）——一旦命中即为堆越界写+证书回读，可把 TA 堆内容（含相邻秘密）带回 NS。
3. 对 CDI_Leaf（base+0x67761）目标：上述原语即使命中 x509 长度 bug，泄露的也是 TA **堆**内容；0x67761 在 RW 全局段（不在堆里），需要额外手段（如堆 grooming 让密钥结构落堆——derive_device_private_key 首次派生时种子确实先落在 malloc 堆 buffer（0x3f92c alloc，拷入全局前）——**堆泄露窗口存在**：0x3f964-0x3fb4c 期间种子在未清零堆中，free 后（0x1c62c，0x3fb50/0x3fb58）不擦除，后续同尺寸 malloc 可能读到残留**。

### 残留种子堆泄露路径（值得实测）
- 0x45038 的 malloc（veneer 0x2d0）**不清零**；0x1c62c free 也不清零（0x3fb50/0x3fb58 连续 free 两个密钥 buffer，无 memset）。
- **SFS 恢复路径（每次开机首次 CSR 必走）**：DK_PRIV 32B 全文先读入堆 buffer（0x3fa80-0x3fa90 `bl #0x40b74` 内分配），memcpy 进 0x67761（0x3fb40-0x3fb4c）后 free（0x3fb58）不擦除 → **完整 32B 种子残留在 TA 堆**。DK_PUB 同理（0x3fb50）。
- 派生路径（首次生成）：KDF 16B 中间值在堆（0x3f92c alloc 0x10），最终 32B key 由 crypto 服务（0x403b0 → veneer 0x2600，输出描述符 = (0x67761, 0x20)，0x40454 `stp x20,x19,[sp,#0x58]`）直写全局，不经堆。
- 若找到任一"分配→未完全覆写→回传 NS"的原语（x509 两遍长度不一致、UPDATE 输出 sizing 等），堆 grooming 后可捞出残留 DK_PRIV。
- 候选响应分配：CSR_V2 的 0x1800 buffer（0x473d0）、RKP_HMAC 的 0x400 buffer（0x43e6c）、ASN.1 INTEGER 临时 buffer（0x227b4 `bl #0x1c5d8`）。

---

# Residue Echo（堆残留回显专项，2026-10-09 静态+真机实证）

## 1. cmd 0x21004（handler 0x6640）定性

```
00006640: bl #0x1969c   ; SFS/GK 写缓冲管理（alloc 0x3000 清零块、登记 0x67b90 块表、
                        ; 日志与 'gk_delete_all_storage_data' 同区）；不碰 x2
00006680: mov w0, w19
0000668c: retab
```
- **从不写响应 descriptor**（[desc+8] 保持 dispatcher 初始值 = 容量-8）→ 框架把整个 TA 侧响应 buffer（0x9ff8 字节）拷回 NS。**机制上是全 buffer 回显原语**。
- 但真机实证（kmcli kumark / seq 模式）：
  - NS 响应 buffer 预填 0x41 → 返回全 0 ⇒ 响应来自 **TA 侧 buffer**（非 NS buffer 直通）；
  - 同会话先发 0x3126（写 375B 响应）再发 0x21004 → 仍全 0 ⇒ **框架每条命令给出的是清零/全新 buffer**（QTEE 拷贝请求时清零或每次新映射零页）。
- 结论：**echo 机制存在，但 TA 侧响应 buffer 无跨命令残留** → 该原语当前只能读零页。heap 残留到不了响应 buffer。

## 2. 响应长度机制与"声明>实写"筛查

响应 descriptor = {ptr, capacity}，handler 必须显式写 [desc+8] 才是真实长度：
- 写法 1：`0x45080`（copy_into_rsp：`str x19,[x20,#8]` 设 used）。
- 写法 2：CBOR 直接编码进 desc buffer 后 finalize（0x479a4: `ldr x8,[sp,#8]; str x8,[x19,#8]`）。
- 低 cmd（<0x2101，如 GET_VERSION 0x10fe0）走另一格式：ret(4B) 后直接写 payload，**无长度字段**（kmcli 对低 cmd 的 len 解析无意义，属正常）。

静态全表扫描（`disasm_tmp/handlerscan.py`，结构体 +8 模式误报率高，仅作初筛）+ 已确认：
| cmd | handler | 状态 |
|---|---|---|
| 0x21004 | 0x6640 | **确认不写长度（实测 len=容量）**，但 buffer 被清零 |
| 0x3122 CSR_V2 / 0x3126 RKP_HMAC / 0x311f ROT | 0x4734c/0x43dd4/0x354b0 | 确认正确设置（实测 len=实际编码长） |
| 0x311c GET_TIMESTAMP_TOKEN(0x4542c)、0x311d(0x2e3c4)、0x21001/0x21002(0x5758/0x620c) | 疑似（静态未见长度写，未实测） | 待 marker 实测 |

## 3. x509 两遍长度族 —— 结论：此路不通

实际设计是**延迟链表**，不是两遍独立计算：
- `0x225c0` 建 ASN ctx；`0x2266c` 把 {tag, ptr, len} 挂链表（不算长度）；
- `0x22f08` 单函数两用：buf=NULL 算总长（0x230d8 遍历同一链表同一 len 字段），buf!=NULL 编码；
- 编码每字节带边界检查（`cmp x20, x21; b.hs stop`），且 `cmp computed, provided; b.ls` 先验；
- cert buffer 由 `0x1c5d8` 分配 = **calloc（清零）**。
推论：即使算/写不一致，尾部也是零（无信息）或截断（不越界）。attestationApplicationId/DeviceInfo/challenge 长度边界（127/128、255/256）fuzz 在这个设计下没有泄露面。**排除。**

## 4. 堆分配器行为（fuzz 尺寸依据）

- app 层 `malloc` = veneer 0x2d0 → TLSF 风格分配器（pool 管理 0x21e08/0x21e20/0x224d0/0x22534，core 0x23d38，cmnlib `qsee_malloc` 0x33238）。TLSF 尺寸分级 freelist，**同级 LIFO**：free 后同尺寸 malloc 基本必然复用同块。
- **`0x1c5d8` = calloc**（malloc+memset，0x1c60c `bl #0x4ad68`）——大部分 app 分配是清零的。
- **`0x45038` = raw malloc**（veneer 0x2d0，**不清零**）+ descriptor 初始化。使用方：CSR_V2（0x1800 响应 staging 0x473d0、challenge/DeviceInfo 精确尺寸 buffer）、RKP_HMAC（0x400×2）、derive_device_private_key（16B KDF buffer 0x3f92c）、generateBcc（0x200）。
- free = veneer 0x90 / 0x1c62c，**不擦除**。
- TA heap 0x4a000（ta_heapSize）。

## 5. 种子堆状态（精确）

- SFS 恢复路径（每次开机首次 CSR 必走）：DK_PRIV **32B 全文**经堆 buffer（SFS read 0x40b74 内分配）→ memcpy 0x67761（0x3fb4c）→ **0x1c62c 释放不擦除（0x3fb58）**。残留块尺寸类 ~0x20-0x30。
- 派生路径：16B KDF 中间值堆块（0x45038 分配），0x450dc 释放不擦除。
- 即：跑过一次 CSR 后，TA 堆里确定存在含完整 CDI_Leaf 种子的空闲块。**缺的只是"堆→响应"的传送带。**

## 6. fuzz 剧本

已实证排除：响应 buffer 回显（零页）、x509 尾部（calloc+截断）。
传送带候选按剩余可能性排序：

**剧本 A（UPDATE 输出路径，最值得做）**
KEYMINT_UPDATE(0x3111)/FINISH(0x3112) 的输出 buffer sizing 未审完。需要先有合法 key blob → 需 GENERATE_KEY（写 SFS，等授权）→ 或用已有 key。靶点：AEAD decrypt UPDATE 的输出 buffer 分配尺寸 vs 实写尺寸。

**剧本 B（疑似 echo 命令 marker 矩阵）**
对每个疑似命令：`kmcli <cmd> a0 kumark`（rsp 预填 0x41），再 `kmcli <cmd> a0` 看返回 len：
- len==40952 → 该 handler 不写长度（echo 候选）；内容非零则有戏。
- 候选：0x311c、0x311d、0x21001、0x21002、0x21004（已知零）、0x2104?? 系列、0x2115(0x2f038 KM_NEW_ATTEST)、0x2116 CONFIGURE。
- 注意 f1/f2 门槛：见命令表。

**剧本 C（跨命令堆喷射+回读，依赖 B 命中）**
若 B 中找到"响应含堆 buffer 尾部"的命令 X：
1. `kmcli 3122 <合法 CSR_V2 请求>`（把 DK_PRIV 带上堆并释放；合法请求格式见 kmclient_notes §4.2/4.4，challenge≤64B）；
2. 紧接若干次 0x45038 路径命令做堆喷射占位；
3. 命令 X 读回，搜种子（可用公钥校验：Ed25519(seed)→pub 对比 CSR 里 UDS pubkey）。

**剧本 D（已成立，直接用）**
FRS 已由 0x219 空 payload 直读（kmclient_notes §4.3）。CDI_Leaf 本体（全局 0x67761）暂无纯命令读原语；堆残留路线卡在"传送带"缺失，剧本 A/B 是唯一剩余静态线索。

---

# CSR Oracle（2026-10-09，已真机验证：设备可签出含攻击者公钥的合法 CSR，无需提取种子）

## 1. GENERATE_CSR_V2 (0x3122) 请求格式（handler 0x4734c，真机验证通过）

请求 payload = **CBOR map**，两个字段：

| label | 内容 | 约束 |
|---|---|---|
| 4 | challenge: bstr | ≤ 64 字节（0x47590 `cmp x1,#0x41; b.hs err`）|
| 57 (0x39) | keysToSign: bstr | 内容为 CBOR 序列（bare item / array / COSE_Mac0 均可）|

字段顺序无关。两个都必填（空 map → -1；缺 challenge → 6）。

keysToSign 的 bstr 内容：HAL 侧（libqtikeymint `generateCertificateRequestV2` @0x22328 → `KeymasterSerialize::serializeGenerateCsrV2` @0x3bf80，label 4=challenge、label 57=keys）把每个 MacedPublicKey（COSE_Mac0 字节）顺序拼接进一个 bstr。**但 TA 的 0x3122 路径不解析 COSE_Mac0、不验 MAC**（见 §3）——bare COSE_Key 字节直接接受。

**最小可用请求样例**（真机验证 retcode=0，CSR 1615B）：
```
# {4: h'0001...1f'(32B challenge), 57: h'<77B COSE_Key P-256>'}
a2045820000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
1839584da5010203262001215820<32B x-coord>225820<32B y-coord>
```
（完整 hex 在 kmcli/reqA.hex；测试密钥对私钥在 kmcli/testkey_pkcs8.hex；COSE_Key = a5 01 02 03 26 20 01 21 5820<x> 22 5820<y>：kty=EC2, alg=ES256, crv=P-256）

TA 流程：parse map → `malloc_csr_payload`/`build_csr_payload`（0x46100/0x46338：CsrPayload = `[3, "keymint", deviceInfo, keysToSign]`，deviceInfo 由 TA 从 `TEE_DEVICE_IDS` 配置属性构造：brand/product/manufacturer/device/model/vb_state/vbmeta_digest/security_level/patch levels/bootloader_state/fused）→ `0x47040` DICE 链 → `0x481a8` 组 SigStructure 并签名（0x4803c=sign_sig_structure，Ed25519，force_sw_dice 选 HW/SW 路径）→ `0x47874` 组 AuthenticatedRequest → `0x479a4` 写响应。

响应 = `{61: bstr}`，bstr = AuthenticatedRequest：`[1, udsCerts{}, DiceCertChain, SignedData]`。
- DiceCertChain = [UDS_Pub(bare COSE_Key Ed25519), DiceChainEntry×3]（本机 4 项；UDS_Pub = CDI_Leaf 公钥）
- SignedData = COSE_Sign1 [bstr{1:-8}, {}, bstr[challenge, bstr CsrPayload], 64B Ed25519 sig]

**真机验证结果**（kmcli/csrA.bin，离线 cryptography 验证）：
- 三级 DICE entry 签名全部 VALID（entry1 由 UDS/CDI_Leaf 私钥签）；
- 顶层 SignedData VALID（对最后一级 KeyMint DICE key）；
- 我们的 P-256 公钥 x 坐标原样出现在 CSR 中，challenge 原样回显。

## 2. MAC 验证逻辑结论

`parseMacTags`（0x4297c）：逐 item 解析 COSE_Mac0（0x3e8f8）→ `calculateCosePublicKeyMac`（0x43c18，RKP HMAC key 重算）→ `memcmp` 32B（0x4ad9c）→ 不符即拒。
**调用方只有 CSR v1（0x311e → 0x431b4 → 0x431d0）和 CSR_V2_FIXED（0x3125 → 0x47ad4 → 0x47e70，flag=0）。**
**0x3122（CSR_V2 非 FIXED）完全不调用它**——无任何 MAC/结构校验。0x3125 FIXED 变体验 MAC，绕开它用 0x3122 即可。

## 3. GENERATE_RKP_HMAC (0x3126) 定性更正

不是任意数据 oracle，是 **generateEcdsaP256KeyPair 的 TA 后端**：
- 请求：`{55: uint}`（55=0x37；0 = 正常模式；真机：{55:0} 成功、{55:1} → -12）。
- TA 行为：内部生成 P-256 密钥对 → 组 COSE_Key（{1:2,3:-7,-1:1,-2:x,-3:y}）→ `calculateCosePublicKeyMac`（0x43c18，HMAC-SHA256，key=全局 0x67790 RKP HMAC key）→ COSE_Mac0；私钥加密成 KMKD blob。
- 响应（375B 样本，kmclient_notes §4.4）：`{23: bstr KMKD_blob, 63: bstr MacedPublicKey}`。
  MacedPublicKey = `84 43 a10105 a0 58 4d <77B COSE_Key> 58 20 <32B HMAC tag>`。
- 对"任意数据 MAC"不可直接利用（只 MAC 自己生成的 key）。EEK 加密不在 TA 请求/响应里（EEK 由 HAL 之后用 fetchEekChain 结果做）。

## 4. Oracle 结论与用法

**目标达成**：0x3122 接受任意公钥（我们持私钥）且无 MAC 校验 → 设备输出经 CDI_Leaf DICE 链背书的合法签名 CSR。提取种子不再必要——设备本身就是签名 oracle。

流程：
1. 本地生成 P-256（或 Ed25519：COSE_Key {1:1,3:-8,-1:6,-2:x}）密钥对；
2. `adb shell su -c 'KMCLI_OUT=/data/local/tmp/csr.bin /data/local/tmp/kmcli 3122 <reqA.hex>'`
3. CSR 可投 Google RKP 服务器（需 HAL 层的 EEK 包装——`ProtectedData` 加密在 NS 侧做，参考 google-rkp-sw/rkp_sw.py 的 build_protected_data）换正式 attestation 证书。

注意：CSR 中 DICE 链/DeviceInfo 是真机身份（含 vbmeta_digest、序列号级信息），生成的证书可追溯到本机。
