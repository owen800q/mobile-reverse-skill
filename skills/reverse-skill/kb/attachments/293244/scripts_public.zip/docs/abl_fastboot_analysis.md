# ABL (abl.img) Fastboot 攻击面分析

- 目标固件: `firmware/abl.img` (Lenovo TB322FC / SM8750P, Android 16, OPD2413_16.0.8.300)
- 工具: capstone 线性反汇编 + ADRP/ADD 字符串 xref（新增脚本 `disasm_tmp/abl_build_db.py`、`disasm_tmp/abl_dis.py`，db 在 `disasm_tmp/db_abl/`）
- **所有地址为 PE 虚拟地址（imgbase=0）**。产物 `disasm_tmp/db_abl/abl_image.bin` = 解压后的完整 PE 映像（0xa2000 字节）。

## 1. 镜像结构（重要：不是明文 ELF，任务书描述有误）

abl.img 实际是 **ELF32/ARM32 容器 + UEFI FV + LZMA 压缩 + PE32+/AArch64** 的多层封装：

| 层 | 内容 |
|---|---|
| ELF32 ET_EXEC | entry=0x9fa00000，phnum=3；phdr[1] LOAD off=0x1000 vaddr=0x9fa00000 filesz=0x39000 RWX |
| phdr[2] NULL | off=0x3a000 size=0xf38 = Qualcomm hash 段（v7，含 SHA-384 段哈希；已验证 SHA384(LOAD) 匹配 @0x3a150，即"密文"就是被签名的内容） |
| LOAD 内容 | **UEFI Firmware Volume**：0x1000+0x10 起 FileSystemGuid=8C8CE578-8A3D-4F1C-9935-896185C32DD3 (FFS2)，`_FVH` @0x1028，FvLength=0x39000 |
| FFS | 单个文件 9E21FD93-9C72-4C15-8C4B-E77F1DB2D792 (COMB_PEIM_DRIVER)，含 GUID_DEFINED 节 GUID=**EE4E5898-3914-4259-9D6E-DC7BD79403CF (LZMA)** |
| LZMA 流 | seg+0x78 起（`5d 00 00 00 01` props+dict16M），解压 0xa20c8 字节 → 内层 FV |
| 内层 FV | FFS F536D559-…(APP)，UI 节 "LinuxLoader"，**裸 PE32+ 紧随其后**（无节头） |
| PE32+ | machine=0xaa64 (AArch64)，entry RVA=0x1000，imgbase=0，.text 0x1000-0x81000 / .data 0x81000-0xa1000 / .reloc 0xa1000-0xa2000 |

所以"LOAD 段熵 8.0"不是加密，是 LZMA 压缩。字符串/代码全在解压后的 PE 里（1170 字符串 / 99738 指令）。

## 2. Fastboot 命令分发表（完整）

表位于 .data `0x873e0`，项 = {char* cmd, void* handler} ×16B，以 `{"none", 0x66c08}` 结尾。共 33 条：

| 命令 | handler | 备注 |
|---|---|---|
| `flash:` | 0x5b55c | §4 门控 |
| `erase:` | 0x5cfb4 | §4 门控 |
| `set_active` | 0x58644 | |
| `flashing get_unlock_ability` | 0x5d458 | 返回全局 `0x9ffec`（unlock_permitted） |
| `flashing unlock` | 0x5d4b4 | **被禁用**：直接回 `"unknow command"` |
| `flashing lock` | 0x5d4f0 | → set_lock_state(0,0) |
| `flashing unlock_critical` | 0x5d52c | → set_lock_state(1,1)，**无 token，但需 0x9ffec**（§5） |
| `flashing lock_critical` | 0x5d568 | → set_lock_state(1,0) |
| `boot` | 0x5d5a4 | 锁态拒绝："Fastboot boot command is not available in locked device" |
| `oem enable-charger-screen` / `oem disable-charger-screen` | 0x5d740 / 0x5d7d4 | |
| `oem off-mode-charge` | 0x5d868 | |
| `oem select-display-panel` | 0x5d9a0 | |
| `oem set-hw-fence-value` | 0x5dd10 | 写 `msm_hw_fence.enable=` cmdline |
| `oem set-gpu-preemption` | 0x5de00 | 写 `msm_kgsl.preempt_enable=` |
| `oem set-more-log` | 0x5def0 | |
| `oem enable-adsp-log` | 0x5dfdc | |
| `oem device-info` | 0x5e0c8 | 打印 Verity mode / Device unlocked / critical unlocked / charger / erase-swap |
| `oem fastboot-hotkey` / `oem recovery-hotkey` / `oem factory-mode` | 0x5e1d8 / 0x5e304 / 0x5e430 | 写设置分区标志 |
| `continue` / `reboot` / `reboot-bootloader` | 0x5e55c / 0x5e5e0 / 0x5e658 | reboot 族后缀（-fastboot/-recovery）在代码内解析 |
| `getvar:` | 0x5e6d4 | §3 |
| `download:` | 0x5e9f0 | 校验 ≤ max-download-size（全局 0xa0040），回 `DATA%08x` |
| `oem audio-framework` | 0x5ec64 | |
| **`oem edl`** | 0x5ecd4 | **`RebootDevice(0xff)` → 进 Sahara/9008；唯一"门"是日志级别检查（0x60378→0x1bcc），锁态可用** |
| `oem token` | 0x60ce0 | 累积 token 段（hex，≤0x240B @0xa062c，总长 @0xa0624，状态 @0xa0628） |
| `oem getRandom` | 0x60be0 | 32B RNG 挑战 → hex 回传；置 token_state=1 |
| `oem unlock-flash` | 0x60f40 | RSA-2048 验签后解锁（§5） |
| `oem lock-flash` | 0x61088 | 回锁 |
| `oem unlock` | 0x5ed50 | 校验 lenovolock 分区结构（§5） |

无 peek/poke/dump/mem/read/upload/fetch 类命令 —— 命令表是穷尽的（"none" 哨兵收尾，全表项均落到已知字符串）。

## 3. getvar 可读变量（锁态可读 = 信息泄露面）

从 getvar 实现区（0x59c00-0x5a800 的字符串 xref）枚举：

`serialno`、`gserialno`、`pserialno`、`imei1`、`imei2`、`meid`、`secure`、`modelname`、`hwboardid`、`product`、`variant`、`version-bootloader`、`version-baseband`、`build.display.id`、`battery-voltage`、`battery-soc-ok`、`charger-screen-enabled`、`off-mode-charge`、`unlocked`、`fastboot-hotkey`、`recovery-hotkey`、`factory-mode`、`hw-revision`、`max-download-size`、`is-userspace`、`kernel`、`uefi`、`parallel-download-flash`、`snapshot-update-status`、`Bootloader_SN_Part1`/`Part2`、`elden_prc_wifi`、`partition-size:`、`partition-type:`、`has-slot:`、`slot-count`/`slot-retry-count`/`slot-unbootable`/`slot-successful`/`slot-suffixes`、`current-slot`、`erase-block-size`、`logical-block-size`。

敏感项：**serialno/gserialno/pserialno/imei1/imei2/meid/secure/hwboardid/Bootloader_SN_Part1-2** —— 无鉴权可读，属设计内的 fastboot 信息泄露（可用于设备指纹/追踪，不能直接提权）。

## 4. flash:/erase: 门控与分区白名单

`flash:` handler 0x5b55c 流程（反汇编证据）：

```
05b698: ldr w8, [x8, #0xfe8]   ; device_locked @0x9ffe8
05b6a0: cbz w8, #0x5b6b4       ; ==0(unlocked) 才继续
05b6a4: "ERROR: device is locked"   ; 锁态：一切 flash 拒绝（包括 unlock.img）
...
05b9d8: bl #0x1ab34  (IsUnlocked)         → 0 则 "Flashing is not allowed in Lock State"
05b9e4: bl #0x1ab60  (IsCriticalUnlocked) → 0 则走 critical 检查
05ba00: bl #0x5f780  (state2/3 下仅 misc/metadata/userdata 放行)
05ba04 失败 → "Flashing of %s is not allowed in %a state"
```

**Critical 分区表**（UTF-16 字符串，.data 0x87618，24 项，`IsCriticalPartition`=0x5f710 遍历）：
`abl, rpm, tz, sdi, xbl, hyp, pmic, bootloader, devinfo, partition, devcfg, ddr, frp, cdt, cmnlib, cmnlib64, keymaster, mdtp, aop, multiimgoem, secdata, imagefv, qupfw, uefisecapp`。

- tz/keymaster/xbl/abl/hyp **都是 critical**：需要 critical-unlock 才能写。
- `lenovolock`、`lenovoraw`、`lenovocust`、`boot`、`vbmeta`、`super` 等 **不在** critical 表：普通 unlock 即可写（erase 同逻辑，0x5d07c/0x5d178 调用同一组检查）。
- flash 时**不做镜像验签/AVB 校验**（avb_custom_key 有专门分支 'Flashing avb_custom_key failed'）；完整性在下次启动由 secure boot/AVB 保证。即解锁后可任意刷写（符合 fastboot 语义），rollback 防御靠 AVB rollback index，flash 路径本身无校验。
- 特殊分支：分区类型 0x164（unlock.img）→ 下载数据 0x164 字节拷到全局缓冲 0xa04bd（0x5b86c-0x5b898），打印 "UnlockImgData = 0x%02x"；该路径同样被 0x9ffe8 锁检查挡住。
- 稀疏镜像解析线程 `SparseImgFlashThread`(0x5840c)、`HandleMetaImgFlash`(0x5c558) 是经典 fuzz 面，但锁态下不可达。

## 5. unlock / lenovolock 逻辑（核心结论）

三条解锁路径：

### 5.1 `flashing unlock` —— 已禁用
handler 0x5d4b4 只回 "unknow command"。标准 AOSP 路径被 Lenovo 拿掉。

### 5.2 `flashing unlock_critical` / `oem unlock` → `set_lock_state`（0x5fef0）
```
05ff20: cbz w0 → IsUnlocked / IsCriticalUnlocked 比较当前态
05ff7c: tst w19 (要解锁?)
05ff84: ldr w8, [x8, #0xfec]    ; unlock_permitted @0x9ffec
05ff8c: cbnz → 继续; 否则 "Flashing Unlock is not allowed\n" 拒绝
05ffb8: GetDeviceState(0x29c38)==3 → 0x600f4; 否则经 UEFI 协议(0x87bd0, +0x140) 交互确认
0600f4: bl #0x1b280 (真正写 lenovolock + 更新全局) → 成功后 RebootDevice(1)
```
`0x9ffec` 唯一写入点在启动初始化（0x5a908）：解析 lenovolock 里的 **unlock.img**，取**最后一个字节 & 1**：
```
05a8f8: ldr w8, [x8, #0xc]
05a900: ldrb w8, [x22, w8, uxtw]   ; img[len-1]
05a904: and w8, w8, #1
05a908: str w8, [x19, #0xfec]      ; unlock_permitted
```
`oem unlock`(0x5ed50) 先跑 `verify_oem_unlock`(0x6215c)：magic `"1a2blenovo3c4d5e"`（memcmp 16B）+ 字段 +0x10==0/+0x14/+0x20 检查 + **SHA-256(结构前 0x64 字节)**（经 UEFI hash 协议，失败打 "verify_oem_unlock: Sha256Hash failed"）+ 再经协议方法读 **0x100 字节安全存储对象交叉比对**（0x622e0-0x62388）。伪造 lenovolock 不足以通过——还要匹配安全存储内容。

### 5.3 `oem getRandom` → `oem token` ×N → `oem unlock-flash` —— Lenovo 官方挑战-应答
```
oem getRandom (0x60be0): 0x60b58 RNG 填 32B 挑战 @0xa064c，hex 回传，token_state=1
oem token    (0x60ce0): hex 段累积到 0xa062c，总 ≤0x240B，"please continue to input token"
oem unlock-flash (0x60f40):
  要求 token_state==1，否则 "ERROR: illegal operation"
  0xe55c  = SHA256(challenge/上下文) → 0xa066c
  0x61efc = verify_token: 0x61bbc init RSA（"init rsa interface fail"）
          0x61d2c(sig@0xa062c, pubkey@0xa06ac, siglen=0x100) = RSA-2048 验签
          失败 "unlock_fail: verify token %d"
  成功 → 0x60b18（清数据）→ 0x61510 写 lenovolock（"deadbeef" magic + 状态字节，0x24B 结构，
         0x61360 写分区；随后擦 lenovoraw/lenovocust）→ "unlock success" → 清 0x9ffe8
```

### 5.4 unlock 可行性结论
- **无离线可伪造路径**。所有解锁路径收敛到：(a) Lenovo RSA-2048 私钥签的 token（挑战-应答，抗重放——挑战是设备真随机）；(b) 出厂/售后预置的 lenovolock 合法结构（magic+SHA256+安全存储交叉校验）。
- lenovolock 不在 critical 表，但**锁态下一切 flash 被拒**（0x9ffe8 检查在 0x164 分支之前），不存在"先刷 lenovolock 再 oem unlock"的鸡生蛋捷径（除非走 9008 program 直写——另议，见 session_notes：此 PBL firehose program 未测）。
- lenovoraw 首 11 字节 == `"CSDK_MAGIC!"` 的工厂模式检测在 0x5ae04（启动时读 lenovoraw 0x20 字节），命中后走 0x5af68 分支——值得后续查它开启什么（疑似工厂/售后模式）。
- 'deadbeef' 只是写 lenovolock 的 magic 标记，不是后门。

## 6. 内存读/写原语结论（负结果，重要）

**fastboot 攻击面内不存在任意内存读/写原语**：无 peek/poke/rdwr/dumpmem/mem/read 命令；无 upload/fetch 反向通道；`download:` 只进不出；`oem getRandom` 只吐 RNG（固定 32B 全局缓冲，无 OOB）。fastboot 响应通道能拿到的只有固定字符串应答和 getvar 变量值。

## 7. 可利用点排序

| 排名 | 原语 | 评估 |
|---|---|---|
| 1 | `oem edl` (0x5ecd4) | **锁态可触发的 9008 重启**。本身不突破（PBL 要签名 programmer，见 session_notes），但与 firehose `read` 组合 = 任意分区读；是后续一切 9008 利用的入口。无需解锁 |
| 2 | getvar 敏感变量（serialno/imei/meid/secure/hwboardid…） | 无鉴权设备指纹泄露，锁态可读 |
| 3 | unlock.img 解析（启动时 0x5a8xx 路径 + flash 0x164 分支拷 0x164B 到 0xa04bd） | 自定义格式 TLV 解析（0x60824/0x60434），若找到 OOB 可影响 unlock_permitted；需解锁后才能投递（或 9008 program） |
| 4 | SparseImgFlashThread / HandleMetaImgFlash | 经典 fastboot 漏洞面（sparse 头部/meta 分区列表解析），锁态不可达；解锁后才可 fuzz |
| 5 | `oem unlock` lenovolock 校验 (0x6215c) | 若能控 lenovolock 内容（9008 写）→ 触发 SHA256/安全存储交叉校验代码，值得审计其边界（0x4c0 栈帧，memcmp/hash） |
| 6 | `oem set-hw-fence-value`/`set-gpu-preemption` 等 cmdline 拼接 | 写内核 cmdline 字段，检查注入（`=`/空格分隔符过滤）即可 |
| — | 任意内存读写 / 分区写（锁态） | **不存在** |

## 8. 复现/工具

```
venv/Scripts/python.exe disasm_tmp/abl_build_db.py     # 解 FV+LZMA+PE，建 db_abl/
venv/Scripts/python.exe disasm_tmp/abl_dis.py 5ed50 0x140   # 反汇编任意 VA
```

关键全局变量（PE VA，运行时需加 PE 加载基址）：
- `0x9ffe8` device_locked（0=unlocked）；`0x9ffec` unlock_permitted（unlock.img 末字节&1）；`0x9ffe1` boot 标志
- `0xa0624` token 总长 / `0xa0628` token 状态 / `0xa062c` token 缓冲（≤0x240B）/ `0xa064c` 32B 挑战 / `0xa06ac` RSA 公钥（运行时填充）/ `0xa04bd` unlock.img 缓冲（0x164B）
